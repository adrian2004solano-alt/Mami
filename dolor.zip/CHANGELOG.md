# Historial de cambios

## 2.6.1 — 13 de octubre de 2026

- Funciona en cualquier hosting y en subcarpetas: todas las rutas son relativas.
- Si el hosting solo sirve archivos (sin el servidor del juego), abre en modo sin conexión en vez de quedarse cargando.
- El zip trae los archivos en la raíz (index.html arriba del todo), listo para subir.

## 2.6.0 — 13 de octubre de 2026

- **Plataforma de juegos**: al entrar se ve un **Inicio** con saldo, botones Recargar/Retirar, el cuadro **Dominó**
  (y espacio para próximos juegos), los mejores jugadores y accesos rápidos. La configuración del dominó está dentro del cuadro.
- **Billetera**: recargas (el jugador envía monto, método y referencia; el admin confirma y se acredita) y retiros
  (se aparta el saldo; el admin lo marca enviado o lo rechaza y se devuelve). Nueva pestaña en el panel de admin.
- **Tienda de estilos**: ambientes, paños, maderas, fichas y puntos de colores se compran con el saldo (avatar gratis).
  Las ventas salen en Rentabilidad.
- **Ranking** con dos listas: más partidas ganadas y más dinero ganado.
- **Registro obligatorio para jugar** (mirar es libre): al tocar jugar, crear o unirse a una sala aparece el registro con código.
- **Descargar la app**: instala la app web o descarga el .apk si `APK_URL` está configurado (ver docs/APP-ANDROID.md).

## 2.5.0 — 13 de octubre de 2026

- **Saldo en dólares (US$)**: se guarda en centavos y se muestra como $10, $18, $1.50. Mesas de $10, $20, $40 y $80.
- Sin regalos automáticos (bienvenida, bono diario y de rescate en 0). El admin puede sumar o restar saldo en dólares.
- Para jugar con dinero: cuenta registrada con correo confirmado y 18 años o más. Gratis sigue abierto para todos.
- Las mesas con dinero son solo entre personas (no se completan con la computadora; `MONEY_BOTS=1` lo cambia).
- El ranking ya no muestra saldos (va por partidas ganadas). Términos actualizados.

## 2.4.0 — 13 de octubre de 2026

- **Sin pozo en ningún modo** (en 1 vs 1 cada uno toma 7 y las demás no se usan). En 1 vs 1 cada pase vale 25.
- **Capicúa +25** extra para quien la hace (puntas distintas, ej. 5 y 2, y dominas con el 5|2).
- **Con monedas o gratis**: se elige antes de entrar (también en salas privadas).
- **Comisión de la plataforma: 10%** de lo que juega cada persona. El ganador cobra el pozo menos el 10%.
- **Panel de admin**: botón "Entrar al panel de admin" en el lobby; nueva pestaña **Rentabilidad** (comisión de hoy,
  7 y 30 días, total, por modo y gráfico de 14 días), total de jugadores, regalar o restar monedas, mensajes de los jugadores.
- **Registro real con correo**: el jugador pone nombre, correo y contraseña, le llega un código de 6 números (Resend) y
  con él confirma su cuenta. Se entra con correo (o nombre) y contraseña.
- Lobby más cómodo en teléfonos pequeños.

## 2.3.0 — 13 de octubre de 2026

- **Tres modos**: Parejas (2 vs 2), 1 vs 1 y **Tríos** (3 jugadores, cada quien solo; 7 fichas cada uno, 7 fuera).
- **Partida rápida (a 100) o normal (a 200)**, para todos los modos, en el lobby y en las salas privadas.
- **Pase +25** para quien jugó. En Parejas solo vale si su compañero (el frente) sí lleva.
- **Pase corrido +30** (nadie más lleva y quien jugó sí): vuelve a jugar; cada vez que se repite, +30 más. Ahora también en Tríos.
- Sale el 6|6 en la primera mano de Parejas; en 1 vs 1 y Tríos, el doble más alto. Después sale el ganador con la ficha que quiera.
- **Tríos**: si alguien abandona o no vuelve tras perder la conexión (45 s), la partida sigue con los que quedan. El ganador cobra el triple.

## 2.2.0 — 13 de octubre de 2026

- **Salas privadas** para jugar con amigos: crea una sala (Parejas o 1 vs 1, de 10 a 80 monedas), invita con un
  **enlace** (`/?sala=CÓDIGO`, se comparte por WhatsApp) o con un **código** de 6 caracteres. Cada quien elige su asiento,
  el anfitrión puede cambiar modo y monto, sacar a alguien y empezar; los asientos vacíos se llenan con BOT.
  Al terminar, la sala queda abierta para la **revancha**. Chat propio de la sala.
- **Supabase** como base de datos de producción: `supabase/migrations/001_domino.sql` (tablas, funciones `dd_*`, RLS y
  permisos) y `server/store/supabase.js` (sin dependencias). SQLite sigue para pruebas locales.
- `npm run check:supabase` revisa la conexión; `/api/health` dice si la base de datos responde.
- El servidor no espera a la base de datos para jugar: las jugadas van directo; solo cobros, premios y cuentas tocan la base.
- Arreglos: el `Dockerfile` ya no usa `VOLUME` (Railway no lo permite); la barra de arriba no se desborda en teléfonos.

## 2.1.0 — 13 de octubre de 2026

- **Ambientes** detrás de la mesa, desenfocados como en una foto: patio de barrio dominicano (flamboyán, casas de colores,
  tinacos, cielo con nubes) y la ciudad con el malecón. Se eligen en Personalizar → Ambiente (también queda el clásico).

## 2.0.0 — 12 de octubre de 2026

- **Lobby** antes de jugar: perfil con avatar, saldo de monedas, bono diario y de rescate, modos Parejas y 1 vs 1,
  montos 10/20/40/80, chat en vivo, personalización, ranking, soporte y perfil.
- **Juego en línea** con servidor propio: cuentas (invitado o con contraseña), emparejamiento, mesas completadas con
  la computadora (marcada BOT), reconexión, abandono, chat de mesa con frases rápidas.
- **Monedas ficticias**: 500 de bienvenida, 100 diarias; al empezar se aparta el monto y el ganador recibe el doble.
- **1 vs 1** con pozo (robar hasta que salga una ficha que sirva), a 100 puntos. Parejas a 200.
- **Servicio al cliente**: preguntas frecuentes, consultas con respuesta dentro del juego y panel `/admin`.
- **Moderación**: groserías tapadas, enlaces bloqueados, límite de mensajes, reportes, silenciar y suspender.
- **Personalización**: avatar (piel, pelo, sombrero, lentes, barba, fondo), paño (bandera, verde, azul, vino), madera
  (nogal, caoba, roble, ébano), fichas (marfil, perla, negras) y puntos de colores.
- Motor de reglas único para servidor y práctica; pruebas con 3.000 partidas simuladas y varios jugadores conectados.

## 1.0.0 — 12 de octubre de 2026

Primera versión pública como proyecto completo.

**Proyecto**
- El juego pasa de un solo archivo HTML a un proyecto organizado: `css/`, `js/` (app, core, game, render), `assets/`.
- Pantalla de carga, botón "Cómo jugar", preferencia de sonido guardada.
- App instalable (manifiesto e iconos) y modo sin conexión.
- SEO e imagen para compartir en redes; página de reglas, privacidad y 404.
- Configuración de Vercel con encabezados de seguridad y caché.
- Pruebas automáticas (35 comprobaciones) y pruebas en GitHub Actions.

**Juego** (lo desarrollado en las versiones de prueba v4–v11)
- Reglas dominicanas: sale el 6|6, pase (25), pase corrido (30, automático), capicúa (puntas distintas), tranque.
- Dobles siempre atravesados y centrados; la ficha siguiente sale del medio del doble; sin choques ni fichas fuera de la mesa.
- Mesa con la bandera dominicana, madera realista, portavasos de acero, vaso de ron.
- Atriles 3D con las fichas recostadas; textura de marfil en las fichas.
- Fin de mano: quien gana le da duro a la mesa, las fichas se desordenan, se voltean y se barajan para la siguiente mano.
- Reparto tocando las fichas de la mesa; ordenar la mano arrastrando; funciona en vertical y horizontal.
