# Dominó Dominicano

Dominó dominicano **en línea** para el navegador: **parejas** y **1 vs 1**, mesas de **10, 20, 40 y 80 monedas** (ficticias),
**salas privadas** para jugar con tus amigos (invitación por **enlace** o **código**), emparejamiento con
personas de cualquier lugar, **chat** con otros jugadores, **servicio al cliente**, **personalización** (avatar, paño, madera y fichas) y **ranking**.
Reglas dominicanas: pase (25), pase corrido (30), capicúa y tranque.

![Dominó Dominicano](assets/og/og-image.jpg)

## Cómo está armado

- **Lobby** (`index.html`): perfil, monedas y bonos, elegir mesa, chat, personalización, ranking, soporte y perfil.
- **Mesa** (mismo `index.html`, en un lienzo): el juego 3D de siempre, ahora movido por eventos del servidor.
- **Servidor** (`server/`): Node.js sin dependencias externas. Cuentas, monedas, emparejamiento, **salas privadas con
  enlace y código**, mesas con la computadora de relleno, chat con moderación, tickets de soporte y panel de administración.
- **Base de datos** (`server/store/`): **Supabase** en producción (`supabase/migrations/001_domino.sql`) o SQLite para
  probar en tu computadora. Se elige solo con las variables `SUPABASE_URL` y `SUPABASE_SECRET_KEY`.
- **Motor de reglas** (`shared/engine.js` y `shared/room.js`): el mismo código decide las jugadas en el servidor y en el
  modo práctica. El servidor es quien manda, así nadie puede hacer trampa ni inventarse monedas.

```
domino-dominicano/
├── index.html            Lobby + mesa
├── admin.html            Panel de soporte (/admin)
├── reglas.html · terminos.html · privacidad.html · 404.html
├── css/                  game.css (mesa) · lobby.css · pages.css · admin.css
├── js/
│   ├── app/              cargador y arranque
│   ├── lobby/            conexión con el servidor y pantallas del lobby
│   ├── core/ game/ render/   la mesa (dibujo, animaciones, toque y arrastre)
│   └── admin.js
├── shared/               motor de reglas, mesa, avatares y temas (navegador y servidor)
├── server/               servidor: index, hub (tiempo real, salas), api, users, moderation, ws, config
│   └── store/            datos: supabase.js (producción) · sqlite.js (pruebas)
├── supabase/migrations/  tablas, funciones y seguridad para Supabase
├── assets/               iconos, imagen para redes, capturas
├── tests/                engine (3.000 partidas), server (varios jugadores), browser (navegador real)
├── docs/                 SUPABASE.md, SERVIDOR.md (cómo publicarlo), ARQUITECTURA.md, LANZAMIENTO.md
└── Dockerfile
```

## Empezar

```bash
npm start            # http://localhost:3000  (Node.js 22.13 o más nuevo)
npm test             # reglas + servidor
```

Para publicarlo: **[docs/SUPABASE.md](docs/SUPABASE.md)** (base de datos) y **[docs/SERVIDOR.md](docs/SERVIDOR.md)** (servidor).

## Licencia

Todos los derechos reservados. Ver [LICENSE](LICENSE).
