/* Dominó Dominicano · motor de reglas (compartido)
 * Lo usa el servidor (partidas en línea) y el navegador (modo práctica). No dibuja nada ni sabe de pantallas:
 * recibe acciones (tomar ficha, jugar, pasar) y devuelve eventos que describen lo que pasó.
 *
 * Modos:
 *   parejas  4 jugadores, dos equipos (0 y 2 contra 1 y 3). Se reparten las 28 fichas, 7 a cada uno.
 *   duelo    1 vs 1. Cada uno toma 7; las 14 que sobran no se usan (no se roba: en ningún modo hay pozo).
 *   trio     3 jugadores, cada uno por su cuenta. 7 fichas cada uno; las 7 que sobran no se usan.
 *            Si alguien se va (abandona o pierde la conexión), la partida sigue con los que quedan.
 * Meta: partida rápida a 100 puntos o normal a 200 (se elige antes de entrar). Gana el primero que llegue.
 *
 * Quién sale: en la primera mano de parejas, el que tenga el doble seis (y sale con él). En 1 vs 1 y tríos, el que tenga
 * el doble más alto (y sale con él). De la segunda mano en adelante sale el que ganó la anterior, con la ficha que quiera.
 *
 * Puntos durante la mano:
 *   Pase (+25): el siguiente jugador no lleva la ficha que jugaste. En parejas solo vale si tu compañero (tu frente)
 *               sí lleva; si tu frente tampoco lleva, el pase no da puntos.
 *   Pase corrido (+30, parejas y tríos): jugaste y nadie más lleva, pero tú sí: +30 y vuelves a jugar. Cada vez, +30 más.
 *               En 1 vs 1 cada pase vale 25.
 *   Tranque: nadie lleva, ni quien jugó. Gana el equipo (o jugador) con menos puntos en la mano.
 *   Capicúa (+25 extra): ganar con una ficha que entra por las dos puntas, siendo las puntas distintas
 *            (ej. puntas 5 y 2, y dominas con el 5|2).
 */
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.DomEngine = factory();
})(typeof self !== 'undefined' ? self : this, function () {
  'use strict';

  // ---- fichas ----
  const TILES = [];
  for (let a = 0; a <= 6; a++) for (let b = a; b <= 6; b++) TILES.push([a, b]);
  const tileOf = (id) => TILES[id];
  const idOf = (a, b) => TILES.findIndex((t) => (t[0] === a && t[1] === b) || (t[0] === b && t[1] === a));
  const pips = (id) => TILES[id][0] + TILES[id][1];
  const isDouble = (id) => TILES[id][0] === TILES[id][1];

  const MODES = {
    parejas: { key: 'parejas', label: 'Parejas', n: 4, teams: true, deal: 7, draw: false, target: 200 },
    duelo: { key: 'duelo', label: '1 vs 1', n: 2, teams: false, deal: 7, draw: false, target: 200 },
    trio: { key: 'trio', label: 'Tríos', n: 3, teams: false, deal: 7, draw: false, target: 200, dropOnLeave: true }
  };
  const TARGETS = [100, 200]; // partida rápida · partida normal
  const PASE_PTS = 25, CORRIDO_PTS = 30, CAPICUA_PTS = 25;

  // ---- azar con semilla (el servidor usa semillas criptográficas) ----
  function rngFrom(seed) {
    let a = seed >>> 0;
    return function () { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
  }
  const shuffle = (arr, rnd) => { for (let i = arr.length - 1; i > 0; i--) { const j = Math.floor(rnd() * (i + 1)); const x = arr[i]; arr[i] = arr[j]; arr[j] = x; } return arr; };

  // ---- dónde quedan las fichas boca abajo para tomarlas (sin encimarse); medidas de la mesa del juego ----
  const BW = 960, BH = 480, TL = 72, TW = 36;
  function obbHit(a, b, m) {
    const ax = [[Math.cos(a.a), Math.sin(a.a)], [-Math.sin(a.a), Math.cos(a.a)], [Math.cos(b.a), Math.sin(b.a)], [-Math.sin(b.a), Math.cos(b.a)]];
    const dx = b.x - a.x, dy = b.y - a.y;
    for (const [nx, ny] of ax) {
      const r = (q) => (TL / 2 + m) * Math.abs(Math.cos(q.a) * nx + Math.sin(q.a) * ny) + (TW / 2 + m) * Math.abs(-Math.sin(q.a) * nx + Math.cos(q.a) * ny);
      if (Math.abs(dx * nx + dy * ny) > r(a) + r(b)) return false;
    }
    return true;
  }
  function deckLayout(rnd) {
    const pts = [], R = (a, b) => a + rnd() * (b - a);
    for (let i = 0; i < 28; i++) {
      let q = null;
      for (const m of [14, 8, 3, 0]) {
        for (let tr = 0; tr < 900 && !q; tr++) { const c = { x: R(-BW / 2 + 56, BW / 2 - 56), y: R(56, BH - 72), a: R(0, 6.28) }; if (pts.every((p) => !obbHit(p, c, m))) q = c; }
        if (q) break;
      }
      if (!q) q = { x: R(-BW / 2 + 56, BW / 2 - 56), y: R(56, BH - 72), a: R(0, 6.28) };
      pts.push({ x: Math.round(q.x * 10) / 10, y: Math.round(q.y * 10) / 10, a: Math.round(q.a * 1000) / 1000 });
    }
    return pts;
  }

  // ---- partida ----
  function newMatch(mode, opts) {
    const cfg = Object.assign({}, MODES[mode] || MODES.parejas, (opts && opts.cfg) || {});
    if (opts && TARGETS.includes(+opts.target)) cfg.target = +opts.target;
    const seed = (opts && opts.seed != null) ? opts.seed : Math.floor(Math.random() * 4294967296);
    return {
      mode: cfg.key, cfg, n: cfg.n, rnd: rngFrom(seed), scores: Array(cfg.teams ? 2 : cfg.n).fill(0), out: Array(cfg.n).fill(false), round: 0, phase: 'idle',
      nextStarter: null, lastStarter: -1, hands: [], deck: [], pos: [], pozo: [], chain: [], ends: null,
      turn: -1, passRun: 0, lastPlayer: -1, mustPlay: null, result: null, winnerTeam: null
    };
  }
  const teamOf = (st, p) => (st.cfg.teams ? p % 2 : p);
  const actives = (st) => [...Array(st.n).keys()].filter((p) => !st.out[p]);
  const nextActive = (st, p) => { for (let d = 1; d <= st.n; d++) { const q = (p + d) % st.n; if (!st.out[q]) return q; } return p; };

  function startRound(st) {
    if (st.phase === 'over') throw new Error('La partida terminó');
    st.round++;
    const ids = shuffle(TILES.map((_, i) => i), st.rnd);
    st.pos = deckLayout(st.rnd);
    st.deck = ids.map((id) => ({ id, owner: -1 }));
    st.hands = Array.from({ length: st.n }, () => []);
    st.pozo = []; st.chain = []; st.ends = null; st.turn = -1; st.passRun = 0; st.lastPlayer = -1; st.mustPlay = null; st.result = null;
    st.phase = 'pick';
    return [{ type: 'round', round: st.round, mode: st.mode, n: st.n, scores: st.scores.slice(), target: st.cfg.target, pos: st.pos }];
  }

  const freeDeck = (st) => st.deck.map((d, i) => (d.owner < 0 ? i : -1)).filter((i) => i >= 0);
  const pickDone = (st) => st.hands.every((h, p) => st.out[p] || h.length >= st.cfg.deal);

  // p toma la ficha i de la mesa (boca abajo)
  function pick(st, p, i) {
    if (st.phase !== 'pick') throw new Error('No es momento de tomar fichas');
    if (st.out[p]) throw new Error('Ya no estás en la mesa');
    if (st.hands[p].length >= st.cfg.deal) throw new Error('Ya tienes tus fichas');
    const d = st.deck[i];
    if (!d || d.owner >= 0) throw new Error('Esa ficha ya la tomaron');
    d.owner = p; st.hands[p].push(d.id);
    const ev = [{ type: 'pick', p, i, tile: d.id, priv: p }];
    if (pickDone(st)) ev.push(...finishDeal(st));
    return ev;
  }

  function finishDeal(st) {
    const ev = [];
    if (st.cfg.draw) {
      st.pozo = freeDeck(st).map((i) => { st.deck[i].owner = 99; return st.deck[i].id; });
      ev.push({ type: 'pozo', idx: st.deck.map((d, i) => (d.owner === 99 ? i : -1)).filter((i) => i >= 0) });
    }
    // quién sale
    let starter = st.nextStarter, must = null;
    if (starter != null && st.out[starter]) starter = nextActive(st, starter);
    if (st.round === 1 || starter == null) {
      if (st.cfg.teams) { must = 27; starter = st.hands.findIndex((h) => h.includes(27)); } // 6|6
      else {
        // el doble más alto que haya en las manos (si nadie tiene doble, la ficha más alta)
        let best = -1, bestScore = -1;
        st.hands.forEach((h, p) => !st.out[p] && h.forEach((id) => { const s = (isDouble(id) ? 100 : 0) + pips(id) * 2 + TILES[id][1] / 10; if (s > bestScore) { bestScore = s; best = p; must = id; } }));
        starter = best;
      }
    }
    st.mustPlay = must; st.lastStarter = starter; st.turn = starter; st.phase = 'play'; st.passRun = 0;
    ev.push({ type: 'start', starter, must, pozo: st.pozo.length });
    ev.push(turnEv(st));
    return ev;
  }

  // ---- jugadas posibles ----
  function legal(st, p) {
    if (st.phase !== 'play') return [];
    const h = st.hands[p], out = [];
    if (!st.chain.length) {
      for (const id of h) if (st.mustPlay == null || id === st.mustPlay) out.push({ id, end: 'C' });
      return out;
    }
    for (const id of h) {
      const [a, b] = TILES[id];
      if (a === st.ends.L || b === st.ends.L) out.push({ id, end: 'L' });
      if (a === st.ends.R || b === st.ends.R) out.push({ id, end: 'R' });
    }
    return out;
  }
  const canPlay = (st, p) => legal(st, p).length > 0;

  function turnEv(st) { return { type: 'turn', p: st.turn, legalFor: st.turn }; }

  function play(st, p, id, end) {
    if (st.phase !== 'play') throw new Error('No es momento de jugar');
    if (st.turn !== p) throw new Error('No es tu turno');
    const mv = legal(st, p).find((m) => m.id === id && (m.end === end || (end == null)));
    if (!mv) throw new Error('Esa ficha no entra ahí');
    end = mv.end;
    const [a, b] = TILES[id];
    const hand = st.hands[p];
    // capicúa: última ficha, entra por las dos puntas y las puntas son distintas
    let cap = false, nums = null;
    if (st.chain.length && hand.length === 1) {
      nums = [st.ends.L, st.ends.R];
      cap = nums[0] !== nums[1] && ((a === nums[0] && b === nums[1]) || (a === nums[1] && b === nums[0]));
    }
    hand.splice(hand.indexOf(id), 1);
    if (end === 'C') st.ends = { L: a, R: b };
    else { const open = st.ends[end]; st.ends[end] = a === open ? b : a; }
    st.chain.push({ p, id, end });
    st.passRun = 0; st.lastPlayer = p; st.mustPlay = null;
    const ev = [{ type: 'play', p, tile: id, end }];
    if (!hand.length) { ev.push(...endRound(st, 'domino', p, cap, nums)); return ev; }
    // sin pozo (parejas y tríos): si nadie más lleva → pase corrido (+30) o tranque
    if (!st.cfg.draw) {
      const others = actives(st).filter((o) => o !== p);
      // con un solo rival (1 vs 1, o tríos que quedaron en dos) no hay corrido: su pase vale 25
      if (others.length === 1 && !canPlay(st, others[0]) && !canPlay(st, p)) { ev.push({ type: 'corrido', p, tranque: true }); ev.push(...endRound(st, 'block')); return ev; }
      if (others.length >= 2 && others.every((o) => !canPlay(st, o))) {
        if (canPlay(st, p)) { // PASE CORRIDO
          st.scores[teamOf(st, p)] += CORRIDO_PTS;
          ev.push({ type: 'corrido', p, pts: CORRIDO_PTS, team: teamOf(st, p), scores: st.scores.slice() });
          st.turn = p; st.passRun = 0; ev.push(turnEv(st));
        } else { // tranque: nadie lleva, ni quien jugó
          ev.push({ type: 'corrido', p, tranque: true });
          ev.push(...endRound(st, 'block'));
        }
        return ev;
      }
    }
    ev.push(...advance(st));
    return ev;
  }

  // siguiente turno (en duelo, quien no lleva roba del pozo hasta que le salga una)
  function advance(st) {
    const ev = [];
    st.turn = nextActive(st, st.turn);
    if (st.cfg.draw) {
      while (!canPlay(st, st.turn) && st.pozo.length) {
        const id = st.pozo.pop(), i = st.deck.findIndex((d) => d.id === id);
        st.deck[i].owner = st.turn; st.hands[st.turn].push(id);
        ev.push({ type: 'draw', p: st.turn, i, tile: id, priv: st.turn, left: st.pozo.length });
      }
    }
    ev.push(turnEv(st));
    return ev;
  }

  function pass(st, p) {
    if (st.phase !== 'play') throw new Error('No es momento de pasar');
    if (st.turn !== p) throw new Error('No es tu turno');
    if (canPlay(st, p)) throw new Error('Tienes ficha para jugar');
    let bonus = null, nobonus = null;
    if (st.passRun === 0 && st.lastPlayer >= 0 && teamOf(st, st.lastPlayer) !== teamOf(st, p)) {
      const team = teamOf(st, st.lastPlayer), nxt = nextActive(st, p);
      // en parejas el pase solo vale si el compañero de quien jugó (el que sigue) sí lleva
      if (st.cfg.teams && teamOf(st, nxt) === team && !canPlay(st, nxt)) nobonus = 'frente';
      else { st.scores[team] += PASE_PTS; bonus = { team, pts: PASE_PTS, giver: st.lastPlayer }; }
    }
    st.passRun++;
    const ev = [{ type: 'pass', p, bonus, nobonus, giver: st.lastPlayer, scores: st.scores.slice() }];
    if (st.passRun >= actives(st).length) { ev.push(...endRound(st, 'block')); return ev; }
    ev.push(...advance(st));
    return ev;
  }

  function endRound(st, kind, winner, cap, nums) {
    const sums = st.hands.map((h) => h.reduce((s, id) => s + pips(id), 0));
    const total = sums.reduce((a, b) => a + b, 0);
    let team = -1, pts = 0, by = winner == null ? -1 : winner;
    const act = actives(st);
    if (!st.cfg.teams) for (const q of st.out.keys()) if (st.out[q]) sums[q] = 0; // quien se fue no cuenta
    const others = (w) => act.filter((q) => q !== w).reduce((a, q) => a + sums[q], 0);
    let capPts = 0;
    if (kind === 'domino') {
      team = teamOf(st, winner);
      pts = st.cfg.teams ? total : others(winner);
      if (cap) { capPts = CAPICUA_PTS; pts += capPts; }
      st.nextStarter = winner;
    } else {
      if (st.cfg.teams) {
        const t0 = sums[0] + sums[2], t1 = sums[1] + sums[3];
        team = t0 < t1 ? 0 : t1 < t0 ? 1 : -1;
        if (team >= 0) { const m = team === 0 ? [0, 2] : [1, 3]; by = sums[m[0]] <= sums[m[1]] ? m[0] : m[1]; pts = total; }
      } else {
        const low = Math.min(...act.map((q) => sums[q])), lows = act.filter((q) => sums[q] === low);
        team = lows.length === 1 ? lows[0] : -1;
        if (team >= 0) { by = team; pts = others(team); }
      }
      st.nextStarter = team >= 0 ? by : nextActive(st, st.lastStarter);
    }
    if (team >= 0) st.scores[team] += pts;
    const { over, winnerTeam } = checkOver(st, team);
    st.phase = over ? 'over' : 'roundEnd'; st.turn = -1; st.winnerTeam = winnerTeam;
    st.result = { kind, winner: by, team, cap: !!cap, capPts, nums: nums || null, pts, sums, hands: st.hands.map((h) => h.slice()), scores: st.scores.slice(), over, winnerTeam };
    return [Object.assign({ type: 'roundEnd' }, st.result)];
  }
  // ¿alguien llegó a la meta? Gana el de más puntos entre los que siguen en la mesa (empate: el que ganó la mano)
  function checkOver(st, lastTeam) {
    const teams = st.cfg.teams ? [0, 1] : actives(st);
    const top = Math.max(...teams.map((t) => st.scores[t]));
    if (top < st.cfg.target) return { over: false, winnerTeam: null };
    const best = teams.filter((t) => st.scores[t] === top);
    return { over: true, winnerTeam: best.includes(lastTeam) ? lastTeam : best[0] };
  }

  // Tríos: un jugador se fue (abandonó o perdió la conexión). La partida sigue con los que quedan.
  function drop(st, p) {
    if (!st.cfg.dropOnLeave || st.out[p] || st.phase === 'over') return [];
    st.out[p] = true;
    const ev = [{ type: 'out', p }], act = actives(st);
    if (act.length === 1) { // quedó uno solo: gana la partida
      const w = act[0];
      st.phase = 'over'; st.turn = -1; st.winnerTeam = teamOf(st, w);
      st.result = { kind: 'abandon', winner: w, team: teamOf(st, w), cap: false, nums: null, pts: 0, sums: st.hands.map(() => 0), hands: st.hands.map((h) => h.slice()), scores: st.scores.slice(), over: true, winnerTeam: st.winnerTeam };
      ev.push(Object.assign({ type: 'roundEnd' }, st.result));
      return ev;
    }
    if (st.phase === 'pick') { if (pickDone(st)) ev.push(...finishDeal(st)); return ev; }
    if (st.phase === 'play') {
      if (st.lastPlayer === p) st.lastPlayer = -1;
      if (st.passRun >= act.length) { ev.push(...endRound(st, 'block')); return ev; }
      if (st.turn === p) ev.push(...advance(st));
    }
    return ev;
  }

  // ---- jugador de la computadora: solo mira su mano y la mesa (no hace trampa) ----
  function botMove(st, p, rnd) {
    const ms = legal(st, p);
    if (!ms.length) return null;
    const r = rnd || Math.random, hand = st.hands[p];
    let best = null, bs = -1e9;
    for (const m of ms) {
      const [a, b] = TILES[m.id];
      const open = m.end === 'C' ? b : (a === st.ends[m.end] ? b : a);
      const other = m.end === 'C' ? a : st.ends[m.end === 'L' ? 'R' : 'L'];
      const rest = hand.filter((x) => x !== m.id);
      const keep = rest.filter((x) => TILES[x].includes(open) || TILES[x].includes(other)).length;
      const sc = a + b + (a === b ? 5 : 0) + keep * 3 + r();
      if (sc > bs) { bs = sc; best = m; }
    }
    return best;
  }
  function botPick(st, rnd) { const f = freeDeck(st); return f.length ? f[Math.floor((rnd || Math.random)() * f.length)] : -1; }

  // ---- lo que ve cada jugador (para reconectarse a una partida) ----
  function viewFor(st, p) {
    return {
      mode: st.mode, n: st.n, me: p, round: st.round, phase: st.phase, scores: st.scores.slice(), target: st.cfg.target, out: st.out.slice(),
      pos: st.pos, deck: st.deck.map((d) => d.owner), hand: (st.hands[p] || []).slice(), counts: st.hands.map((h) => h.length),
      pozo: st.pozo.length, chain: st.chain.map((c) => ({ p: c.p, tile: c.id, end: c.end })), ends: st.ends,
      turn: st.turn, mustPlay: st.mustPlay, legal: st.turn === p ? legal(st, p) : [], result: st.result
    };
  }

  // quita de los eventos lo que p no debe ver (las fichas de los demás)
  function redact(ev, p) {
    return ev.map((e) => {
      if (e.priv != null && e.priv !== p) { const c = Object.assign({}, e); delete c.tile; delete c.priv; return c; }
      if (e.priv != null) { const c = Object.assign({}, e); delete c.priv; return c; }
      return e;
    });
  }

  const numTeams = (mode) => (MODES[mode].teams ? 2 : MODES[mode].n);
  return { TILES, MODES, TARGETS, PASE_PTS, CORRIDO_PTS, CAPICUA_PTS, numTeams, actives, drop, tileOf, idOf, pips, isDouble, rngFrom, newMatch, startRound, pick, freeDeck, pickDone, legal, canPlay, play, pass, teamOf, botMove, botPick, viewFor, redact };
});
