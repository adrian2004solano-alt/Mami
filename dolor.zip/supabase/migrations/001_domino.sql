-- Dominó Dominicano · base de datos en Supabase (Postgres)
-- Cómo usarlo: Supabase → SQL Editor → pega TODO este archivo → Run. Se puede correr más de una vez sin romper nada.
--
-- Cómo funciona:
--  * El servidor del juego (Node.js) es el único que habla con la base de datos, con la clave service_role.
--  * El navegador NUNCA habla con Supabase: no necesita la clave anon y no hay que crear políticas RLS públicas.
--  * Toda la lógica de datos está en funciones dd_<operación>(p jsonb) que el servidor llama por
--    POST /rest/v1/rpc/dd_<operación>  con el cuerpo {"p": {...}}.
--  * RLS está activado en todas las tablas y sin políticas: con la clave anon no se puede leer ni escribir nada.
--  * Dinero (users.coins, ledger, matches.stake/collected/fee/paid) en CENTAVOS de dólar: 1000 = US$10.00.
--  * Fechas en milisegundos desde 1970 (bigint), igual que Date.now() en JavaScript.

-- =====================================================================
-- TABLAS
-- =====================================================================
create table if not exists public.users (
  id          bigint generated always as identity primary key,
  name        text not null,
  name_lc     text not null unique,
  pass        text,
  salt        text,
  registered  boolean not null default false,
  coins       bigint  not null default 0 check (coins >= 0),
  avatar      text,
  prefs       text,
  games       integer not null default 0,
  wins        integer not null default 0,
  coins_won   bigint  not null default 0,
  daily_day   integer not null default 0,
  rescue_at   bigint  not null default 0,
  muted_until bigint  not null default 0,
  banned      boolean not null default false,
  ban_reason  text,
  created     bigint  not null,
  last_seen   bigint  not null
);
-- 2.4: correo verificado (registro con código)
alter table public.users add column if not exists email text;
alter table public.users add column if not exists owned text not null default '[]';  -- 2.6: artículos comprados en la tienda
create unique index if not exists users_email on public.users (email) where email is not null;
create index if not exists users_coins on public.users (coins desc, wins desc);
create index if not exists users_last_seen on public.users (last_seen desc);

create table if not exists public.sessions (
  token_hash text primary key,
  user_id    bigint not null references public.users(id) on delete cascade,
  created    bigint not null,
  last       bigint not null
);
create index if not exists sessions_user on public.sessions (user_id);

create table if not exists public.email_codes (
  user_id   bigint primary key references public.users(id) on delete cascade,
  email     text   not null,
  payload   jsonb,                 -- nombre y contraseña (ya cifrada) que se guardan al confirmar el código
  code_hash text   not null,       -- solo el hash del código, nunca el código
  expires   bigint not null,
  attempts  integer not null default 0,
  sent_at   bigint not null
);

-- 2.6: billetera (recargas y retiros que aprueba el admin)
create table if not exists public.payments (
  id       bigint generated always as identity primary key,
  user_id  bigint not null references public.users(id) on delete cascade,
  kind     text   not null check (kind in ('deposit','withdraw')),
  amount   bigint not null check (amount > 0),            -- centavos
  method   text   not null,
  details  text,
  status   text   not null default 'pendiente' check (status in ('pendiente','aprobado','rechazado')),
  note     text,
  created  bigint not null,
  resolved bigint
);
create index if not exists payments_status on public.payments (status, id);
create index if not exists payments_user on public.payments (user_id, id desc);

create table if not exists public.ledger (
  id      bigint generated always as identity primary key,
  user_id bigint not null references public.users(id) on delete cascade,
  delta   bigint not null,
  balance bigint not null,
  reason  text   not null,
  ref     text,
  created bigint not null
);
create index if not exists ledger_user on public.ledger (user_id, id desc);

create table if not exists public.chat (
  id      bigint generated always as identity primary key,
  user_id bigint  not null,
  name    text    not null,
  avatar  text,
  text    text    not null,
  created bigint  not null,
  deleted boolean not null default false
);

create table if not exists public.reports (
  id          bigint generated always as identity primary key,
  reporter_id bigint not null,
  target_id   bigint,
  msg_id      bigint,
  text        text,
  reason      text,
  created     bigint  not null,
  resolved    boolean not null default false
);

create table if not exists public.tickets (
  id           bigint generated always as identity primary key,
  user_id      bigint not null references public.users(id) on delete cascade,
  category     text not null,
  subject      text not null,
  status       text not null default 'abierto' check (status in ('abierto','respondido','cerrado')),
  unread_user  boolean not null default false,
  unread_admin boolean not null default true,
  created      bigint not null,
  updated      bigint not null
);
create index if not exists tickets_user on public.tickets (user_id, updated desc);

create table if not exists public.ticket_msgs (
  id         bigint generated always as identity primary key,
  ticket_id  bigint not null references public.tickets(id) on delete cascade,
  from_admin boolean not null default false,
  text       text not null,
  created    bigint not null
);
create index if not exists ticket_msgs_ticket on public.ticket_msgs (ticket_id, id);

create table if not exists public.matches (
  id        text primary key,
  mode      text   not null,
  stake     bigint not null,
  status    text   not null check (status in ('activa','terminada','anulada')),
  players   jsonb  not null default '[]'::jsonb,
  result    jsonb,
  charged   jsonb  not null default '[]'::jsonb,   -- ids de quienes pagaron la apuesta (para devolverla si se interrumpe)
  room_code text,                                 -- código de la sala privada, si la partida salió de una invitación
  created   bigint not null,
  ended     bigint
);
-- 2.4: comisión de la plataforma (se agrega aunque la tabla ya exista)
alter table public.matches add column if not exists collected bigint not null default 0;  -- monedas cobradas a las personas
alter table public.matches add column if not exists fee       bigint not null default 0;  -- comisión de la plataforma (10%)
alter table public.matches add column if not exists paid      bigint not null default 0;  -- premios pagados
create index if not exists matches_status on public.matches (status);
create index if not exists matches_created on public.matches (created desc);

-- =====================================================================
-- AYUDANTE INTERNO: mover monedas dejando constancia (nunca deja saldo negativo)
-- =====================================================================
create or replace function public._dd_move(p_uid bigint, p_delta bigint, p_reason text, p_ref text, p_now bigint)
returns bigint language plpgsql set search_path = public, pg_temp as $$
declare bal bigint;
begin
  update users set coins = coins + p_delta where id = p_uid and coins + p_delta >= 0 returning coins into bal;
  if not found then return null; end if;
  insert into ledger (user_id, delta, balance, reason, ref, created) values (p_uid, p_delta, bal, p_reason, p_ref, p_now);
  return bal;
end $$;

-- =====================================================================
-- CUENTAS
-- =====================================================================
create or replace function public.dd_user_get(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select to_jsonb(u) from users u where u.id = (p->>'id')::bigint
$$;

create or replace function public.dd_user_by_name(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select to_jsonb(u) from users u where u.name_lc = p->>'name_lc'
$$;

create or replace function public.dd_guest_create(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint; t bigint := (p->>'now')::bigint;
begin
  insert into users (name, name_lc, coins, avatar, prefs, created, last_seen)
  values (p->>'name', coalesce(p->>'name_lc', lower(p->>'name')), 0, p->>'avatar', p->>'prefs', t, t)
  returning id into uid;
  if coalesce((p->>'coins')::bigint, 0) <> 0 then perform _dd_move(uid, (p->>'coins')::bigint, 'bienvenida', null, t); end if;
  return (select to_jsonb(u) from users u where u.id = uid);
exception when unique_violation then
  return null;
end $$;

create or replace function public.dd_session_create(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  insert into sessions (token_hash, user_id, created, last)
  values (p->>'hash', (p->>'uid')::bigint, (p->>'now')::bigint, (p->>'now')::bigint);
  select 'true'::jsonb
$$;

create or replace function public.dd_session_user(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint; r jsonb; t bigint := (p->>'now')::bigint;
begin
  update sessions set last = t where token_hash = p->>'hash' returning user_id into uid;
  if uid is null then return null; end if;
  update users u set last_seen = t where u.id = uid returning to_jsonb(u.*) into r;
  return r;
end $$;

create or replace function public.dd_session_delete(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  delete from sessions where token_hash = p->>'hash';
  select 'true'::jsonb
$$;

create or replace function public.dd_user_register(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare r jsonb; cn text;
begin
  update users u set name = p->>'name', name_lc = coalesce(p->>'name_lc', lower(p->>'name')), pass = p->>'pass', salt = p->>'salt', registered = true,
                     email = coalesce(p->>'email', u.email)
  where u.id = (p->>'id')::bigint returning to_jsonb(u.*) into r;
  return jsonb_build_object('user', r);
exception when unique_violation then
  get stacked diagnostics cn = constraint_name;
  return jsonb_build_object('error', case when cn like '%email%' then 'correo' else 'nombre' end);
end $$;

create or replace function public.dd_user_by_email(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select to_jsonb(u) from users u where u.email = lower(p->>'email')
$$;

create or replace function public.dd_email_code_set(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  insert into email_codes (user_id, email, payload, code_hash, expires, attempts, sent_at)
  values ((p->>'uid')::bigint, lower(p->>'email'), case when jsonb_typeof(p->'payload') = 'object' then p->'payload' end,
          p->>'code_hash', (p->>'expires')::bigint, 0, (p->>'now')::bigint)
  on conflict (user_id) do update set email = excluded.email, payload = coalesce(excluded.payload, email_codes.payload),
          code_hash = excluded.code_hash, expires = excluded.expires, attempts = 0, sent_at = excluded.sent_at;
  select 'true'::jsonb
$$;

create or replace function public.dd_email_code_get(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select jsonb_build_object('email', email, 'payload', payload) from email_codes where user_id = (p->>'uid')::bigint
$$;

create or replace function public.dd_email_code_check(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare r record; uid bigint := (p->>'uid')::bigint;
begin
  select * into r from email_codes where user_id = uid for update;
  if not found then return jsonb_build_object('error', 'ninguno'); end if;
  if r.attempts >= 5 then return jsonb_build_object('error', 'intentos'); end if;
  if (p->>'now')::bigint > r.expires then return jsonb_build_object('error', 'vencido'); end if;
  if r.code_hash <> p->>'code_hash' then
    update email_codes set attempts = attempts + 1 where user_id = uid;
    return jsonb_build_object('error', 'incorrecto');
  end if;
  delete from email_codes where user_id = uid;
  return jsonb_build_object('ok', true, 'email', r.email, 'payload', r.payload);
end $$;

create or replace function public.dd_user_update(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare r jsonb;
begin
  update users u set
    name    = coalesce(p->>'name', u.name),
    name_lc = coalesce(p->>'name_lc', case when p ? 'name' and p->>'name' is not null then lower(p->>'name') end, u.name_lc),
    avatar  = coalesce(p->>'avatar', u.avatar),
    prefs   = coalesce(p->>'prefs', u.prefs)
  where u.id = (p->>'id')::bigint returning to_jsonb(u.*) into r;
  return jsonb_build_object('user', r);
exception when unique_violation then
  return jsonb_build_object('error', 'nombre');
end $$;

create or replace function public.dd_claim_daily(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint := (p->>'id')::bigint; d integer := (p->>'day')::integer;
begin
  update users set daily_day = d where id = uid and daily_day < d;
  if not found then return null; end if;
  return to_jsonb(_dd_move(uid, (p->>'amount')::bigint, 'bono diario', null, (p->>'now')::bigint));
end $$;

create or replace function public.dd_claim_rescue(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint := (p->>'id')::bigint; t bigint := (p->>'now')::bigint;
begin
  update users set rescue_at = t
  where id = uid and coins < (p->>'min_stake')::bigint and t - rescue_at >= (p->>'every_ms')::bigint;
  if not found then return null; end if;
  return to_jsonb(_dd_move(uid, (p->>'amount')::bigint, 'bono de rescate', null, t));
end $$;

create or replace function public.dd_leaderboard(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  -- sin saldos (es dinero real): por partidas ganadas o por lo más ganado
  select case when p->>'by' = 'money' then
    (select coalesce(jsonb_agg(to_jsonb(x) order by x.won desc, x.wins desc), '[]'::jsonb) from (
      select id, name, avatar, wins, games, coins_won as won from users where not banned and coins_won > 0 order by coins_won desc, wins desc limit 25) x)
  else
    (select coalesce(jsonb_agg(to_jsonb(x) order by x.wins desc, x.games), '[]'::jsonb) from (
      select id, name, avatar, wins, games, coins_won as won from users where not banned and games > 0 order by wins desc, games limit 25) x)
  end
$$;

create or replace function public.dd_history(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('delta', x.delta, 'balance', x.balance, 'reason', x.reason, 'created', x.created) order by x.id desc), '[]'::jsonb)
  from (select * from ledger where user_id = (p->>'uid')::bigint order by id desc limit 40) x
$$;

create or replace function public.dd_move_coins(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  select to_jsonb(_dd_move((p->>'uid')::bigint, (p->>'delta')::bigint, p->>'reason', p->>'ref', (p->>'now')::bigint))
$$;

-- =====================================================================
-- CHAT Y REPORTES
-- =====================================================================
create or replace function public.dd_chat_add(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare nid bigint;
begin
  insert into chat (user_id, name, avatar, text, created)
  values ((p->>'uid')::bigint, p->>'name', p->>'avatar', p->>'text', (p->>'now')::bigint) returning id into nid;
  if nid % 200 = 0 then delete from chat where id < nid - 5000; end if;
  return to_jsonb(nid);
end $$;

create or replace function public.dd_chat_recent(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'uid', x.user_id, 'name', x.name, 'avatar', x.avatar, 'text', x.text, 'ts', x.created) order by x.id), '[]'::jsonb)
  from (select * from chat where not deleted order by id desc limit coalesce((p->>'n')::integer, 60)) x
$$;

create or replace function public.dd_chat_get(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select to_jsonb(c) from chat c where c.id = (p->>'id')::bigint
$$;

create or replace function public.dd_chat_delete(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  update chat set deleted = true where id = (p->>'id')::bigint;
  select 'true'::jsonb
$$;

create or replace function public.dd_report_add(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  insert into reports (reporter_id, target_id, msg_id, text, reason, created)
  values ((p->>'reporter')::bigint, (p->>'target')::bigint, (p->>'msg_id')::bigint, p->>'text', p->>'reason', (p->>'now')::bigint);
  select 'true'::jsonb
$$;

-- =====================================================================
-- PARTIDAS Y MONEDAS
-- =====================================================================
-- Cobra la apuesta a cada jugador (al que no le alcance se queda fuera) y registra la partida como activa.
create or replace function public.dd_match_start(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare u text; bal bigint; t bigint := (p->>'now')::bigint; st bigint := (p->>'stake')::bigint;
        charged jsonb := '[]'::jsonb; failed jsonb := '[]'::jsonb; ids jsonb := '[]'::jsonb; coll bigint;
begin
  for u in select jsonb_array_elements_text(p->'uids') loop
    bal := _dd_move(u::bigint, -st, 'apuesta', p->>'id', t);
    if bal is null then failed := failed || to_jsonb(u::bigint);
    else charged := charged || jsonb_build_object('uid', u::bigint, 'coins', bal); ids := ids || to_jsonb(u::bigint);
    end if;
  end loop;
  if jsonb_array_length(charged) > 0 then
    coll := st * jsonb_array_length(charged);
    insert into matches (id, mode, stake, status, players, charged, room_code, created, collected, fee)
    values (p->>'id', p->>'mode', st, 'activa', '[]'::jsonb, ids, p->>'room_code', t, coll,
            round(coll * coalesce((p->>'fee_rate')::numeric, 0)));
  end if;
  return jsonb_build_object('charged', charged, 'failed', failed);
end $$;

create or replace function public.dd_match_players(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  update matches set players = coalesce(p->'players', '[]'::jsonb) where id = p->>'id';
  select 'true'::jsonb
$$;

-- Paga el premio a los ganadores, suma estadísticas y cierra la partida (una sola vez).
create or replace function public.dd_match_settle(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare r record; bal bigint; t bigint := (p->>'now')::bigint; st bigint := (p->>'stake')::bigint; prize bigint := (p->>'prize')::bigint;
        out jsonb := '[]'::jsonb; total_paid bigint := 0;
begin
  update matches set status = 'terminada', result = p->'result', ended = t where id = p->>'id' and status = 'activa';
  if not found then return out; end if;
  for r in select * from jsonb_to_recordset(coalesce(p->'results', '[]'::jsonb)) as x(uid bigint, won boolean) loop
    if r.won then bal := _dd_move(r.uid, prize, 'premio', p->>'id', t); if bal is not null then total_paid := total_paid + prize; end if;
    else select coins into bal from users where id = r.uid;
    end if;
    update users set games = games + 1,
                     wins = wins + (case when r.won then 1 else 0 end),
                     coins_won = coins_won + (case when r.won then prize - st else 0 end)
    where id = r.uid;
    out := out || jsonb_build_object('uid', r.uid, 'coins', bal);
  end loop;
  update matches set paid = total_paid where id = p->>'id';
  return out;
end $$;

-- Si el servidor se reinició con partidas a medias, devuelve las apuestas.
create or replace function public.dd_match_void_active(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare m record; u text; n integer := 0; t bigint := (p->>'now')::bigint;
begin
  for m in select * from matches where status = 'activa' for update loop
    for u in select jsonb_array_elements_text(m.charged) loop
      perform _dd_move(u::bigint, m.stake, 'devolución (partida interrumpida)', m.id, t);
    end loop;
    update matches set status = 'anulada', ended = t, fee = 0, paid = collected where id = m.id;
    n := n + 1;
  end loop;
  return to_jsonb(n);
end $$;

-- =====================================================================
-- SERVICIO AL CLIENTE
-- =====================================================================
create or replace function public.dd_tickets_mine(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(to_jsonb(x) order by x.updated desc), '[]'::jsonb)
  from (select * from tickets where user_id = (p->>'uid')::bigint order by updated desc limit 50) x
$$;

create or replace function public.dd_ticket_create(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare nid bigint; t bigint := (p->>'now')::bigint;
begin
  insert into tickets (user_id, category, subject, created, updated)
  values ((p->>'uid')::bigint, p->>'category', p->>'subject', t, t) returning id into nid;
  insert into ticket_msgs (ticket_id, text, created) values (nid, p->>'text', t);
  return to_jsonb(nid);
end $$;

create or replace function public._dd_ticket_msgs(p_id bigint) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('admin', from_admin, 'text', text, 'created', created) order by id), '[]'::jsonb)
  from ticket_msgs where ticket_id = p_id
$$;

create or replace function public.dd_ticket_get_mine(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare tk jsonb; tid bigint := (p->>'id')::bigint;
begin
  select to_jsonb(t) into tk from tickets t where t.id = tid and t.user_id = (p->>'uid')::bigint;
  if tk is null then return null; end if;
  update tickets set unread_user = false where id = tid;
  return jsonb_build_object('ticket', tk, 'messages', _dd_ticket_msgs(tid));
end $$;

create or replace function public.dd_ticket_add_msg(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare tid bigint := (p->>'id')::bigint; t bigint := (p->>'now')::bigint;
begin
  perform 1 from tickets where id = tid and user_id = (p->>'uid')::bigint;
  if not found then return 'false'::jsonb; end if;
  insert into ticket_msgs (ticket_id, text, created) values (tid, p->>'text', t);
  update tickets set status = 'abierto', unread_admin = true, updated = t where id = tid;
  return 'true'::jsonb;
end $$;

-- =====================================================================
-- ADMINISTRACIÓN (el servidor solo las llama si la petición trae la ADMIN_KEY correcta)
-- =====================================================================
create or replace function public.dd_admin_stats(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select jsonb_build_object(
    'pendingPays',  (select count(*) from payments where status = 'pendiente'),
    'users',        (select count(*) from users),
    'registered',   (select count(*) from users where registered),
    'matchesToday', (select count(*) from matches where created > (p->>'now')::bigint - 86400000),
    'openTickets',  (select count(*) from tickets where status = 'abierto'),
    'openReports',  (select count(*) from reports where not resolved),
    'coins',        (select coalesce(sum(coins), 0) from users)
  )
$$;

-- Rentabilidad: comisiones (10%), lo cobrado y lo pagado en partidas terminadas
create or replace function public._dd_rev(p_from bigint) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select jsonb_build_object('matches', count(*), 'collected', coalesce(sum(collected), 0), 'fee', coalesce(sum(fee), 0),
                            'paid', coalesce(sum(paid), 0), 'net', coalesce(sum(collected), 0) - coalesce(sum(paid), 0))
  from matches where status = 'terminada' and created >= p_from
$$;
create or replace function public.dd_admin_revenue(p jsonb) returns jsonb
language plpgsql stable set search_path = public, pg_temp as $$
declare d bigint := 86400000; tz bigint := coalesce((p->>'tz_ms')::bigint, 0); n bigint := (p->>'now')::bigint; t0 bigint;
begin
  t0 := ((n + tz) / d) * d - tz;
  return jsonb_build_object(
    'today', _dd_rev(t0), 'week', _dd_rev(t0 - 6 * d), 'month', _dd_rev(t0 - 29 * d), 'total', _dd_rev(0),
    'shop', (select jsonb_build_object('sales', count(*), 'amount', coalesce(-sum(delta), 0)) from ledger where reason like 'tienda:%'),
    'wallet', (select jsonb_build_object(
        'deposits', coalesce(sum(amount) filter (where kind = 'deposit' and status = 'aprobado'), 0),
        'withdrawals', coalesce(sum(amount) filter (where kind = 'withdraw' and status = 'aprobado'), 0),
        'pending', count(*) filter (where status = 'pendiente')) from payments),
    'byMode', (select coalesce(jsonb_agg(x order by x.fee desc), '[]'::jsonb) from (
       select mode, count(*) as matches, coalesce(sum(fee), 0) as fee, coalesce(sum(collected), 0) as collected
       from matches where status = 'terminada' group by mode) x),
    'daily', (select coalesce(jsonb_agg(jsonb_build_object('day', x.dd * d, 'matches', x.matches, 'fee', x.fee) order by x.dd), '[]'::jsonb) from (
       select (created + tz) / d as dd, count(*) as matches, coalesce(sum(fee), 0) as fee
       from matches where status = 'terminada' and created >= t0 - 13 * d group by 1) x)
  );
end $$;

-- Tienda: comprar un estilo de mesa/fichas con el saldo
create or replace function public.dd_shop_buy(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint := (p->>'uid')::bigint; it text := p->>'item'; pr bigint := (p->>'price')::bigint; ow jsonb; bal bigint;
begin
  select owned::jsonb, coins into ow, bal from users where id = uid for update;
  if not found then return jsonb_build_object('error', 'usuario'); end if;
  if ow ? it then return jsonb_build_object('error', 'ya'); end if;
  if pr > 0 then bal := _dd_move(uid, -pr, 'tienda: ' || it, it, (p->>'now')::bigint); end if;
  if bal is null then return jsonb_build_object('error', 'saldo'); end if;
  ow := ow || to_jsonb(it);
  update users set owned = ow::text where id = uid;
  return jsonb_build_object('coins', bal, 'owned', ow);
end $$;

-- Billetera: pedir recarga o retiro (el retiro aparta el saldo de una vez)
create or replace function public.dd_pay_create(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint := (p->>'uid')::bigint; amt bigint := (p->>'amount')::bigint; k text := p->>'kind'; t bigint := (p->>'now')::bigint; nid bigint;
begin
  perform 1 from users where id = uid for update;
  if k = 'withdraw' then
    if exists (select 1 from payments where user_id = uid and kind = 'withdraw' and status = 'pendiente') then return jsonb_build_object('error', 'pendiente'); end if;
    if _dd_move(uid, -amt, 'retiro solicitado', null, t) is null then return jsonb_build_object('error', 'saldo'); end if;
  elsif (select count(*) from payments where user_id = uid and kind = 'deposit' and status = 'pendiente') >= 3 then
    return jsonb_build_object('error', 'muchas');
  end if;
  insert into payments (user_id, kind, amount, method, details, created) values (uid, k, amt, p->>'method', p->>'details', t) returning id into nid;
  return jsonb_build_object('id', nid, 'coins', (select coins from users where id = uid));
end $$;

create or replace function public.dd_pay_mine(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'kind', x.kind, 'amount', x.amount, 'method', x.method, 'status', x.status, 'note', x.note, 'created', x.created, 'resolved', x.resolved) order by x.id desc), '[]'::jsonb)
  from (select * from payments where user_id = (p->>'uid')::bigint order by id desc limit 30) x
$$;

create or replace function public.dd_admin_pays(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(x.j order by x.pend desc, x.id desc), '[]'::jsonb) from (
    select y.id, (y.status = 'pendiente') as pend, to_jsonb(y) || jsonb_build_object('name', u.name, 'email', u.email, 'coins', u.coins) as j
    from payments y join users u on u.id = y.user_id
    where p->>'status' is null or y.status = p->>'status'
    order by (y.status = 'pendiente') desc, y.id desc limit 100
  ) x
$$;

create or replace function public.dd_admin_pay_resolve(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare r record; ok boolean := coalesce((p->>'approve')::boolean, false); t bigint := (p->>'now')::bigint;
begin
  select * into r from payments where id = (p->>'id')::bigint and status = 'pendiente' for update;
  if not found then return null; end if;
  if r.kind = 'deposit' and ok then perform _dd_move(r.user_id, r.amount, 'recarga', 'pago ' || r.id, t); end if;
  if r.kind = 'withdraw' and not ok then perform _dd_move(r.user_id, r.amount, 'retiro rechazado (devolución)', 'pago ' || r.id, t); end if;
  update payments set status = case when ok then 'aprobado' else 'rechazado' end, note = p->>'note', resolved = t where id = r.id;
  return jsonb_build_object('user_id', r.user_id, 'kind', r.kind, 'amount', r.amount, 'status', case when ok then 'aprobado' else 'rechazado' end,
                            'coins', (select coins from users where id = r.user_id));
end $$;

create or replace function public.dd_admin_tickets(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(x.j order by x.open desc, x.updated desc), '[]'::jsonb) from (
    select to_jsonb(t) || jsonb_build_object('name', u.name) as j, (t.status = 'abierto') as open, t.updated
    from tickets t join users u on u.id = t.user_id
    where p->>'status' is null or t.status = p->>'status'
    order by (t.status = 'abierto') desc, t.updated desc limit 100
  ) x
$$;

create or replace function public.dd_admin_ticket(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare tk jsonb; tid bigint := (p->>'id')::bigint;
begin
  select to_jsonb(t) || jsonb_build_object('name', u.name, 'coins', u.coins, 'uid', u.id) into tk
  from tickets t join users u on u.id = t.user_id where t.id = tid;
  if tk is null then return null; end if;
  update tickets set unread_admin = false where id = tid;
  return jsonb_build_object('ticket', tk, 'messages', _dd_ticket_msgs(tid));
end $$;

create or replace function public.dd_admin_reply(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare tid bigint := (p->>'id')::bigint; t bigint := (p->>'now')::bigint; tk record;
begin
  select * into tk from tickets where id = tid;
  if not found then return null; end if;
  insert into ticket_msgs (ticket_id, from_admin, text, created) values (tid, true, p->>'text', t);
  update tickets set status = case when coalesce((p->>'close')::boolean, false) then 'cerrado' else 'respondido' end,
                     unread_user = true, updated = t where id = tid;
  return jsonb_build_object('user_id', tk.user_id, 'subject', tk.subject);
end $$;

create or replace function public.dd_admin_ticket_close(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  update tickets set status = 'cerrado', updated = (p->>'now')::bigint where id = (p->>'id')::bigint;
  select 'true'::jsonb
$$;

create or replace function public.dd_admin_reports(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(x.j order by x.id desc), '[]'::jsonb) from (
    select r.id, to_jsonb(r) || jsonb_build_object('reporter', a.name, 'target', b.name, 'muted_until', b.muted_until, 'banned', b.banned) as j
    from reports r left join users a on a.id = r.reporter_id left join users b on b.id = r.target_id
    where not r.resolved order by r.id desc limit 100
  ) x
$$;

create or replace function public.dd_admin_report_resolve(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  update reports set resolved = true where id = (p->>'id')::bigint;
  select 'true'::jsonb
$$;

create or replace function public.dd_admin_chat(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(jsonb_build_object('id', x.id, 'user_id', x.user_id, 'name', x.name, 'text', x.text, 'created', x.created, 'deleted', x.deleted) order by x.id desc), '[]'::jsonb)
  from (select * from chat order by id desc limit 100) x
$$;

create or replace function public.dd_admin_users(p jsonb) returns jsonb
language sql stable set search_path = public, pg_temp as $$
  select coalesce(jsonb_agg(to_jsonb(x) order by x.last_seen desc), '[]'::jsonb) from (
    select id, name, coins, registered, games, wins, muted_until, banned, ban_reason, created, last_seen from users
    where coalesce(p->>'q', '') = ''
       or name_lc like '%' || lower(p->>'q') || '%'
       or id = case when p->>'q' ~ '^[0-9]{1,15}$' then (p->>'q')::bigint else -1 end
    order by last_seen desc limit 50
  ) x
$$;

create or replace function public.dd_admin_mute(p jsonb) returns jsonb
language sql set search_path = public, pg_temp as $$
  update users set muted_until = (p->>'until')::bigint where id = (p->>'id')::bigint;
  select 'true'::jsonb
$$;

create or replace function public.dd_admin_ban(p jsonb) returns jsonb
language plpgsql set search_path = public, pg_temp as $$
declare uid bigint := (p->>'id')::bigint; b boolean := coalesce((p->>'ban')::boolean, false);
begin
  update users set banned = b, ban_reason = case when b then p->>'reason' end where id = uid;
  if b then delete from sessions where user_id = uid; end if;
  return 'true'::jsonb;
end $$;

-- =====================================================================
-- SEGURIDAD
-- =====================================================================
-- RLS activado y SIN políticas: las claves anon/authenticated no pueden ver ni tocar estas tablas.
alter table public.users       enable row level security;
alter table public.sessions    enable row level security;
alter table public.ledger      enable row level security;
alter table public.chat        enable row level security;
alter table public.reports     enable row level security;
alter table public.tickets     enable row level security;
alter table public.ticket_msgs enable row level security;
alter table public.matches     enable row level security;
alter table public.email_codes enable row level security;
alter table public.payments    enable row level security;

revoke all on public.users, public.sessions, public.ledger, public.chat, public.reports, public.tickets, public.ticket_msgs, public.matches, public.email_codes, public.payments from anon, authenticated;
grant usage on schema public to service_role;
grant select, insert, update, delete on public.users, public.sessions, public.ledger, public.chat, public.reports, public.tickets, public.ticket_msgs, public.matches, public.email_codes, public.payments to service_role;

-- Solo el servidor (service_role) puede ejecutar las funciones del juego.
do $$
declare f record;
begin
  for f in
    select p.oid::regprocedure as sig from pg_proc p join pg_namespace n on n.oid = p.pronamespace
    where n.nspname = 'public' and (p.proname like 'dd\_%' or p.proname like '\_dd\_%')
  loop
    execute format('revoke all on function %s from public, anon, authenticated', f.sig);
    execute format('grant execute on function %s to service_role', f.sig);
  end loop;
end $$;

-- Que la API de Supabase vea las funciones nuevas de inmediato.
notify pgrst, 'reload schema';
