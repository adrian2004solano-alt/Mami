// Cambia la versión del juego en todos los lugares a la vez (package.json, js/app/version.js y sw.js).
// Uso: npm run version:bump -- 1.1.0
// Hazlo antes de cada publicación: así los jugadores que tienen el juego instalado reciben la versión nueva.
import { readFileSync, writeFileSync } from 'node:fs';
const v = process.argv[2];
if (!/^\d+\.\d+\.\d+$/.test(v || '')) { console.error('Indica la versión, por ejemplo: npm run version:bump -- 1.1.0'); process.exit(1); }
const edit = (f, re, rep) => { const s = readFileSync(f, 'utf8'); if (!re.test(s)) throw new Error('No encontré la versión en ' + f); writeFileSync(f, s.replace(re, rep)); console.log('✔', f); };
edit('package.json', /"version":\s*"[^"]+"/, `"version": "${v}"`);
edit('js/app/version.js', /APP_VERSION = '[^']+'/, `APP_VERSION = '${v}'`);
edit('sw.js', /const VERSION = '[^']+'/, `const VERSION = '${v}'`);
console.log('Versión →', v, '· recuerda anotar los cambios en CHANGELOG.md');
