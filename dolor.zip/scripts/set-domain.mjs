// Cambia el dominio del sitio en todos los archivos (enlaces para Google y para compartir en redes).
// Uso: npm run domain -- https://www.tudominio.com
import { readFileSync, writeFileSync } from 'node:fs';
const OLD = 'https://domino-dominicano.vercel.app';
let nu = (process.argv[2] || '').replace(/\/+$/, '');
if (!/^https:\/\/[a-z0-9.-]+\.[a-z]{2,}$/i.test(nu)) { console.error('Indica el dominio completo, por ejemplo: npm run domain -- https://www.tudominio.com'); process.exit(1); }
for (const f of ['index.html', 'reglas.html', 'privacidad.html', 'terminos.html', 'robots.txt', 'sitemap.xml']) {
  const s = readFileSync(f, 'utf8'); const n = s.split(OLD).length - 1;
  if (n) { writeFileSync(f, s.split(OLD).join(nu)); console.log(`✔ ${f} (${n})`); }
}
console.log('Listo. Si cambias de dominio otra vez, edita OLD en este script.');
