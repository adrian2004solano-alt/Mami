// Dominó Dominicano · envío de correos (código de verificación)
// Usa Resend (https://resend.com) por su API HTTPS: no hay que instalar nada.
//   RESEND_API_KEY = re_…        (Resend → API Keys)
//   MAIL_FROM      = "Dominó Dominicano <no-responder@tu-dominio.com>"  (dominio verificado en Resend)
// Sin RESEND_API_KEY (en tu computadora) el código se escribe en la consola del servidor en vez de enviarse.
import { CFG } from './config.js';

const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);

export async function sendCode(to, code, name) {
  const subject = `${code} es tu código de Dominó Dominicano`;
  const text = `Hola ${name || ''}:\n\nTu código para confirmar tu correo es: ${code}\n\nVence en ${CFG.EMAIL_CODE_MIN} minutos. Si no fuiste tú, ignora este mensaje.\n\nDominó Dominicano`;
  const html = `<div style="font-family:system-ui,Arial,sans-serif;max-width:420px;margin:auto;padding:24px;background:#22150d;color:#f5ecd9;border-radius:16px">
<h1 style="font-family:Georgia,serif;font-size:22px;margin:0 0 12px">Dominó Dominicano</h1>
<p>Hola ${esc(name || '')}, tu código para confirmar tu correo es:</p>
<p style="font-size:34px;font-weight:800;letter-spacing:8px;color:#ffcf4a;margin:16px 0">${code}</p>
<p style="color:#b8a487;font-size:13px">Vence en ${CFG.EMAIL_CODE_MIN} minutos. Si no fuiste tú, ignora este mensaje.</p></div>`;
  if (!CFG.RESEND_API_KEY) { console.log(`[correo] (sin RESEND_API_KEY) código para ${to}: ${code}`); return { ok: true, dev: true }; }
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { Authorization: 'Bearer ' + CFG.RESEND_API_KEY, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: CFG.MAIL_FROM, to: [to], subject, text, html })
  });
  if (!res.ok) { const t = await res.text().catch(() => ''); console.error('Resend', res.status, t.slice(0, 300)); return { ok: false }; }
  return { ok: true };
}
