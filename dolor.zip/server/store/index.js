// Dominó Dominicano · dónde se guardan los datos
// - Si están SUPABASE_URL y SUPABASE_SECRET_KEY (o SUPABASE_SERVICE_ROLE_KEY) → Supabase (producción).
// - Si no → SQLite en DATA_DIR/domino.db (para probar en tu computadora).
// Se puede forzar con DB_DRIVER=sqlite o DB_DRIVER=supabase.
import { CFG } from '../config.js';
import { createSqliteStore } from './sqlite.js';
import { createSupabaseStore } from './supabase.js';

function pick() {
  const want = (process.env.DB_DRIVER || '').toLowerCase();
  const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SECRET_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (want === 'supabase' || (!want && url && key)) return createSupabaseStore({ url, key });
  return createSqliteStore(CFG);
}
export const store = pick();
export const call = (name, args) => store.call(name, args);
export const now = () => Date.now();
