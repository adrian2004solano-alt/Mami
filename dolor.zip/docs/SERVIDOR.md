# Poner el juego en línea

El juego tiene dos partes que se publican por separado:

1. **La base de datos en Supabase** (cuentas, monedas, historial, chat, soporte): **[SUPABASE.md](SUPABASE.md)**.
2. **El servidor del juego** (este proyecto, Node.js): sirve la página, la API y el tiempo real (WebSocket) donde se
   arman las mesas, las salas privadas y las partidas. Necesita un hosting que mantenga un programa encendido.

**Recomendado: Railway** (~US$5 al mes). También sirven Render (plan pago, el gratis se duerme), Fly.io o un VPS con Docker.
Usa **una sola instancia** (sin réplicas): las mesas y salas en vivo están en la memoria del servidor.

## Railway paso a paso

1. Sube el proyecto a GitHub (ver más abajo).
2. En [railway.com](https://railway.com) → **New Project → Deploy from GitHub repo** → elige `domino-dominicano`.
   Railway detecta el `Dockerfile` y lo construye solo.
3. En **Variables** agrega (lista completa en [`.env.example`](../.env.example)):
   | Variable | Valor |
   |---|---|
   | `SUPABASE_URL` | `https://<proyecto>.supabase.co` |
   | `SUPABASE_SECRET_KEY` | la clave secreta de Supabase (`sb_secret_…` o `service_role`) |
   | `ADMIN_KEY` | una clave larga y secreta (para el panel de soporte en `/admin`) |
4. **Settings → Networking → Generate Domain** (o conecta tu dominio propio). Abre la dirección: ya está el juego.
   Revisa `https://tu-direccion/api/health` → debe decir `"db":"supabase","dbOk":true`.
5. Corre `npm run domain -- https://tu-direccion` y vuelve a subir, para que Google y la vista previa de WhatsApp usen tu dirección
   (también es la dirección que llevan los enlaces de invitación a las salas).

Cada cambio que subas a GitHub se publica solo. Como los datos están en Supabase, no hace falta volumen ni disco.

> Sin las variables de Supabase el servidor usa SQLite (un archivo en `DATA_DIR`). Sirve para probar en tu computadora;
> en un hosting necesitarías un volumen montado en `/data`, y se borra todo si no lo tienes.

### ¿Página en Vercel y servidor en Railway?

Se puede: en `js/app/server-url.js` pon la dirección del servidor (`https://….up.railway.app`) y en el servidor
`ALLOWED_ORIGINS=https://tu-sitio.vercel.app`. Lo más simple, de todos modos, es dejar todo en Railway.

## Subir a GitHub

```bash
git add .
git commit -m "Dominó Dominicano"
git remote add origin https://github.com/TU-USUARIO/domino-dominicano.git
git push -u origin main
```

## Variables que puedes ajustar

| Variable | Por defecto | Qué hace |
|---|---|---|
| `ADMIN_KEY` | (vacía) | Clave del panel `/admin`. Sin ella el panel está apagado. |
| `SUPABASE_URL` / `SUPABASE_SECRET_KEY` | (vacías) | Base de datos en Supabase. Sin ellas se usa SQLite. |
| `DATA_DIR` | `./data` | Solo con SQLite: carpeta del archivo `domino.db`. |
| `SALA_IDLE_MS` | 1800000 | Una sala privada sin movimiento se cierra a los 30 minutos. |
| `SALA_OFFLINE_MS` | 90000 | Si alguien se desconecta en la sala de espera, su asiento se libera al minuto y medio. |
| `START_COINS` | 500 | Monedas de bienvenida. |
| `DAILY_COINS` | 100 | Bono diario. |
| `RESCUE_COINS` / `RESCUE_EVERY_H` | 50 / 6 | Bono si te quedas sin monedas. |
| `QUEUE_WAIT_MS` | 12000 | Tiempo que se espera a otras personas antes de completar la mesa con la computadora. |
| `ALLOWED_ORIGINS` | (vacía) | Si pones el sitio en un dominio distinto al del servidor. |

Los montos de las mesas (10, 20, 40, 80) están en `server/config.js` (`STAKES`).

## Panel de soporte

Entra a `https://tu-direccion/admin` con tu `ADMIN_KEY`. Desde ahí:
- respondes las consultas de los jugadores (les llega aviso en el juego),
- revisas los reportes del chat, borras mensajes y silencias o suspendes cuentas,
- ajustas monedas a un jugador (por ejemplo, para compensar un error).

## Copias de seguridad

Con Supabase: **Database → Backups** (diarias en los planes pagos). En el plan gratis, exporta de vez en cuando
(`supabase db dump` o Table Editor → Export). Con SQLite, todo está en `DATA_DIR/domino.db`.

## Probar en tu computadora

Necesitas Node.js 22.13 o más nuevo.

```bash
npm start                 # http://localhost:3000
ADMIN_KEY=prueba npm start   # con panel de soporte
npm test                  # reglas (3.000 partidas simuladas) + servidor con varios jugadores (incluye salas privadas)
SUPABASE_URL=… SUPABASE_SECRET_KEY=… npm start       # con tu base de Supabase
SUPABASE_URL=… SUPABASE_SECRET_KEY=… npm run check:supabase   # revisar la conexión
```
