// Prueba en navegador real: el lobby carga, dos personas juegan una partida 1 vs 1 completa y el modo práctica funciona.
// Uso: npm run test:browser   (la primera vez: npm install && npm run test:setup)
import { chromium } from 'playwright';
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
const root = fileURLToPath(new URL('..', import.meta.url)), PORT = 5299, BASE = `http://localhost:${PORT}/`;
const dataDir = mkdtempSync(join(tmpdir(), 'domino-br-'));
let fails = 0; const ok = (n, c, x = '') => { console.log(c ? '  ✔' : '  ✘', n, c ? '' : x); if (!c) fails++; };
const srv = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { cwd: root, env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir, QUEUE_WAIT_MS: '3000', GUEST_PER_HOUR: '1000', STAKES: '10,20,40,80', START_COINS: '500', MONEY_BOTS: '1', MONEY_NEEDS_ACCOUNT: '0', PLAY_NEEDS_ACCOUNT: '0' }, stdio: 'ignore' });
await new Promise((r) => setTimeout(r, 900));
const AUTO = () => { window.__auto = setInterval(() => {
  if (phase === 'pick' && now >= pickOpen && got[0] < DEAL && !deck.some((d) => d.pending && !d.taken)) { const f = deck.filter((d) => !d.taken && !d.pozo); if (f.length) { const d = f[Math.floor(Math.random() * f.length)]; d.pending = now; ACT({ t: 'pick', i: d.i }); } }
  if (canAct() && legalNow.length) { const m = legalNow[0], it = H.find((i) => i.t.id === m.id); if (it) sendPlay(it, { name: m.end }); }
  else if (phase === 'play' && turn === 0 && passBtn && !knock) { passBtn = null; ACT({ t: 'pass' }); }
}, 250); };
const browser = await chromium.launch(); const errors = [];
try {
  const pages = [];
  for (let i = 0; i < 2; i++) { const ctx = await browser.newContext({ viewport: { width: 1280, height: 640 } }); const pg = await ctx.newPage(); pg.on('pageerror', (e) => errors.push(String(e))); await pg.goto(BASE); pages.push(pg); }
  await pages[0].waitForFunction(() => typeof LOBBY !== 'undefined' && LOBBY.online, null, { timeout: 15000 });
  ok('el lobby carga con cuenta de invitado y 500 monedas', await pages[0].evaluate(() => LOBBY.me.coins === 500));
  await pages[0].click('#gDomino'); await pages[1].click('#gDomino');
  await pages[0].fill('#chatIn', 'Hola'); await pages[0].click('#chatForm button');
  await pages[1].waitForFunction(() => document.querySelectorAll('#msgs .msg').length > 0, null, { timeout: 5000 });
  ok('el chat llega a otra persona', true);
  for (const pg of pages) { await pg.waitForFunction(() => typeof LOBBY !== 'undefined' && LOBBY.online); await pg.waitForFunction(() => typeof CONF !== 'undefined' && CONF.playNeedsAccount === false); await pg.click('.mode[data-mode="duelo"]'); await pg.click('#playBtn'); }
  await pages[0].waitForFunction(() => !document.getElementById('stage').hidden, null, { timeout: 15000 });
  for (const pg of pages) await pg.evaluate(AUTO);
  await pages[0].waitForFunction(() => document.getElementById('modal').style.display === 'flex' && !!lastEnd, null, { timeout: 300000, polling: 1000 });
  const a = await pages[0].evaluate(() => LOBBY.me.coins), b = await pages[1].evaluate(() => LOBBY.me.coins);
  ok('partida 1 vs 1 completa: el ganador cobra 18 de 20 (10% de comisión)', [a, b].sort().join() === '490,508', a + ' ' + b);
  const pr = pages[0]; await pr.click('#mbtns button:last-child'); await pr.click('#practiceBtn'); await pr.evaluate(AUTO);
  await pr.waitForFunction(() => round >= 1 && phase === 'play' && chain.length > 2, null, { timeout: 60000 });
  ok('modo práctica en parejas', true);
  ok('sin errores de JavaScript', errors.length === 0, errors.slice(0, 3).join(' | '));
} catch (e) { fails++; console.error(e); }
finally { await browser.close(); srv.kill(); rmSync(dataDir, { recursive: true, force: true }); }
console.log(fails ? `${fails} con fallas` : 'Todo bien'); process.exit(fails ? 1 : 0);
