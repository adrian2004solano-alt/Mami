// Pruebas del motor de reglas: miles de partidas completas entre jugadores de la computadora.
// Uso: node tests/engine.test.mjs
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const E = require('../shared/engine.js');
let fails = 0; const ok = (n, c, x = '') => { if (c) console.log('  ✔', n); else { fails++; console.log('  ✘', n, x); } };

function runMatch(mode, seed, target) {
  const st = E.newMatch(mode, { seed, target });
  const stats = { rounds: 0, corridos: 0, pases: 0, caps: 0, tranques: 0, draws: 0, errors: [], bonus: 0 };
  let guard = 0;
  while (st.phase !== 'over' && guard++ < 200) {
    E.startRound(st); stats.rounds++;
    // tomar fichas por turnos
    let p = 0, g2 = 0;
    while (st.phase === 'pick' && g2++ < 100) { if (st.hands[p].length < st.cfg.deal) E.pick(st, p, E.botPick(st)); p = (p + 1) % st.n; }
    const scoreBefore = st.scores.slice();
    let g3 = 0, bonusPts = 0;
    while (st.phase === 'play' && g3++ < 500) {
      const q = st.turn, m = E.botMove(st, q);
      // invariante: las fichas siempre suman 28
      const n = st.hands.reduce((s, h) => s + h.length, 0) + st.chain.length + st.pozo.length + st.deck.filter(d => d.owner < 0).length;
      if (n !== 28) stats.errors.push('fichas ' + n);
      const ev = m ? E.play(st, q, m.id, m.end) : E.pass(st, q);
      for (const e of ev) {
        if (e.type === 'corrido' && !e.tranque) { stats.corridos++; bonusPts += e.pts; }
        if (e.type === 'pass') { stats.pases++; if (e.bonus) bonusPts += e.bonus.pts; }
        if (e.type === 'draw') stats.draws++;
        if (e.type === 'roundEnd') { if (e.cap) stats.caps++; if (e.kind === 'block') stats.tranques++;
          if (e.cap && e.nums[0] === e.nums[1]) stats.errors.push('capicúa con puntas iguales');
          const sum = (a) => a.reduce((x, y) => x + y, 0), gained = sum(e.scores) - sum(scoreBefore);
          if (gained !== bonusPts + e.pts) stats.errors.push('puntos no cuadran ' + gained + ' vs ' + (bonusPts + e.pts)); }
      }
      // la cola siempre encaja
      for (let i = 1; i < st.chain.length; i++) { /* verificado por legal() */ }
    }
    if (st.phase === 'play') stats.errors.push('mano sin terminar');
    stats.bonus += bonusPts;
  }
  return { st, stats };
}

for (const [mode, target] of [['parejas', 200], ['duelo', 200], ['trio', 200], ['parejas', 100], ['duelo', 100], ['trio', 100]]) {
  console.log('Modo', mode, 'a', target);
  const tot = { matches: 0, rounds: 0, corridos: 0, pases: 0, caps: 0, tranques: 0, draws: 0, errors: [] };
  for (let s = 1; s <= 1500; s++) {
    const { st, stats } = runMatch(mode, s, target);
    tot.matches++; for (const k of ['rounds', 'corridos', 'pases', 'caps', 'tranques', 'draws']) tot[k] += stats[k];
    tot.errors.push(...stats.errors);
    if (st.phase !== 'over') tot.errors.push('partida sin terminar');
    if (st.winnerTeam == null || st.scores[st.winnerTeam] < target || st.scores.some((x) => x > st.scores[st.winnerTeam])) tot.errors.push('ganador mal ' + st.scores);
  }
  console.log('   ', JSON.stringify({ ...tot, errors: tot.errors.length }));
  ok(`1500 partidas completas sin errores (${tot.rounds} manos)`, tot.errors.length === 0, tot.errors.slice(0, 5).join(' | '));
  if (mode !== 'duelo') ok('hay pases corridos y capicúas', tot.corridos > 0 && tot.caps > 0);
  if (mode === 'duelo') ok('1 vs 1 sin pozo: nunca se roba', tot.draws === 0 && tot.corridos === 0);
}

console.log('Reglas puntuales');
{ // sale el 6|6 en parejas
  const st = E.newMatch('parejas', { seed: 7 }); E.startRound(st);
  let p = 0; while (st.phase === 'pick') { if (st.hands[p].length < 7) E.pick(st, p, E.botPick(st)); p = (p + 1) % 4; }
  const holder = st.hands.findIndex(h => h.includes(27));
  ok('sale quien tiene el 6|6', st.turn === holder && E.legal(st, holder).length === 1 && E.legal(st, holder)[0].id === 27);
  let err = null; try { E.play(st, (holder + 1) % 4, st.hands[(holder + 1) % 4][0], 'C'); } catch (e) { err = e.message; }
  ok('no se puede jugar fuera de turno', !!err);
}
{ // capicúa y no capicúa (montado a mano)
  const st = E.newMatch('parejas', { seed: 1 }); E.startRound(st);
  st.phase = 'play'; st.hands = [[E.idOf(4, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 1)], [E.idOf(1, 3)]];
  st.chain = [{ p: 1, id: E.idOf(4, 2), end: 'C' }]; st.ends = { L: 4, R: 2 }; st.turn = 0;
  const ev = E.play(st, 0, E.idOf(4, 2), 'L');
  const re = ev.find(e => e.type === 'roundEnd');
  ok('capicúa con puntas 4 y 2 jugando 4|2: +25 extra', re.cap === true && re.capPts === 25 && st.scores[0] === re.pts && re.pts === 25 + re.sums.reduce((a, b) => a + b, 0));
  const st2 = E.newMatch('parejas', { seed: 1 }); E.startRound(st2);
  st2.phase = 'play'; st2.hands = [[E.idOf(6, 3)], [E.idOf(0, 0)], [E.idOf(1, 1)], [E.idOf(1, 3)]]; st2.ends = { L: 6, R: 6 }; st2.chain = [{ p: 1, id: 27, end: 'C' }]; st2.turn = 0;
  const ev2 = E.play(st2, 0, E.idOf(6, 3), 'L');
  ok('no es capicúa con puntas iguales', ev2.find(e => e.type === 'roundEnd').cap === false);
}
{ // pase corrido y pase normal
  const st = E.newMatch('parejas', { seed: 1 }); E.startRound(st);
  st.phase = 'play'; st.hands = [[E.idOf(5, 5), E.idOf(5, 3), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 1), E.idOf(1, 2)], [E.idOf(1, 3), E.idOf(3, 3)]];
  st.chain = [{ p: 3, id: E.idOf(5, 4), end: 'C' }]; st.ends = { L: 5, R: 4 }; st.turn = 0; st.scores = [0, 0];
  st.hands[0] = [E.idOf(4, 5), E.idOf(5, 3), E.idOf(2, 2)];
  const ev = E.play(st, 0, E.idOf(4, 5), 'R');
  const c = ev.find(e => e.type === 'corrido');
  ok('pase corrido: +30 y vuelve a jugar quien jugó', c && c.pts === 30 && st.scores[0] === 30 && st.turn === 0);
  const st2 = E.newMatch('parejas', { seed: 1 }); E.startRound(st2);
  st2.phase = 'play'; st2.hands = [[E.idOf(4, 5), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 5), E.idOf(1, 2)], [E.idOf(1, 3), E.idOf(3, 3)]];
  st2.chain = [{ p: 3, id: E.idOf(5, 4), end: 'C' }]; st2.ends = { L: 5, R: 4 }; st2.turn = 0;
  E.play(st2, 0, E.idOf(4, 5), 'R');
  const ev2 = E.pass(st2, 1);
  ok('pase normal: +25 para el equipo de quien jugó', ev2[0].bonus && ev2[0].bonus.team === 0 && st2.scores[0] === 25);
}
{ // duelo: el pozo
  const st = E.newMatch('duelo', { seed: 3 }); E.startRound(st);
  let p = 0; while (st.phase === 'pick') { if (st.hands[p].length < 7) E.pick(st, p, E.botPick(st)); p = 1 - p; }
  ok('1 vs 1: 7 y 7, sin pozo', st.hands[0].length === 7 && st.hands[1].length === 7 && st.pozo.length === 0);
  const v = E.viewFor(st, 0), red = E.redact([{ type: 'pick', p: 1, i: 0, tile: 5, priv: 1 }], 0);
  ok('no se ven las fichas del rival', red[0].tile === undefined && v.hand.length === 7 && !('hands' in v));
}
{ // parejas: el pase solo vale si el frente de quien jugó sí lleva
  const st = E.newMatch('parejas', { seed: 1 }); E.startRound(st);
  // 0 juega 4|5 (puntas 5 y 5). 1 no lleva 5; 2 (su frente) tampoco; 3 sí.
  st.phase = 'play'; st.hands = [[E.idOf(4, 5), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 1), E.idOf(1, 2)], [E.idOf(5, 3), E.idOf(3, 3)]];
  st.chain = [{ p: 3, id: E.idOf(5, 4), end: 'C' }]; st.ends = { L: 5, R: 4 }; st.turn = 0; st.scores = [0, 0];
  E.play(st, 0, E.idOf(4, 5), 'R');
  const ev = E.pass(st, 1);
  ok('pase sin puntos si el frente tampoco lleva', !ev[0].bonus && ev[0].nobonus === 'frente' && st.scores[0] === 0);
  const ev2 = E.pass(st, 2);
  ok('el frente pasa y tampoco suma nadie', !ev2[0].bonus && st.scores[1] === 0 && st.turn === 3);
}
{ // meta: rápida (100) y normal (200)
  ok('partida rápida a 100 y normal a 200', E.newMatch('parejas', { target: 100 }).cfg.target === 100 && E.newMatch('duelo', { target: 200 }).cfg.target === 200 && E.newMatch('trio', { target: 7 }).cfg.target === 200);
}
{ // tríos
  const st = E.newMatch('trio', { seed: 5 }); E.startRound(st);
  let p = 0; while (st.phase === 'pick') { if (st.hands[p].length < 7) E.pick(st, p, E.botPick(st)); p = (p + 1) % 3; }
  const best = (() => { let b = -1, bp = -1; st.hands.forEach((h, q) => h.forEach((id) => { const sc = (E.isDouble(id) ? 100 : 0) + E.pips(id) * 2 + E.tileOf(id)[1] / 10; if (sc > b) { b = sc; bp = q; } })); return bp; })();
  ok('tríos: 7 fichas cada uno, 7 fuera y sale el doble más alto', st.hands.every((h) => h.length === 7) && st.deck.filter((d) => d.owner < 0).length === 7 && st.turn === best && E.legal(st, best).length === 1);
  const t = E.newMatch('trio', { seed: 2 }); E.startRound(t);
  t.phase = 'play'; t.hands = [[E.idOf(4, 5), E.idOf(5, 3), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(1, 1), E.idOf(1, 2)]];
  t.chain = [{ p: 2, id: E.idOf(5, 4), end: 'C' }]; t.ends = { L: 5, R: 4 }; t.turn = 0;
  const ev = E.play(t, 0, E.idOf(4, 5), 'R');
  ok('tríos: nadie más lleva → +30 para quien jugó y vuelve a jugar', ev.some((e) => e.type === 'corrido' && e.pts === 30) && t.scores[0] === 30 && t.turn === 0);
  const u = E.newMatch('trio', { seed: 2 }); E.startRound(u);
  u.phase = 'play'; u.hands = [[E.idOf(4, 5), E.idOf(2, 2)], [E.idOf(0, 0), E.idOf(0, 1)], [E.idOf(5, 1), E.idOf(1, 2)]];
  u.chain = [{ p: 2, id: E.idOf(5, 4), end: 'C' }]; u.ends = { L: 5, R: 4 }; u.turn = 0;
  E.play(u, 0, E.idOf(4, 5), 'R'); const pv = E.pass(u, 1);
  ok('tríos: pase +25 para quien jugó', pv[0].bonus && pv[0].bonus.team === 0 && u.scores[0] === 25 && u.turn === 2);
  const d = E.drop(u, 2);
  ok('tríos: si alguien se va, sigue la partida con dos', d[0].type === 'out' && u.phase === 'play' && u.turn === 0 && E.actives(u).length === 2);
  const d2 = E.drop(u, 1), end = d2.find((e) => e.type === 'roundEnd');
  ok('tríos: si queda uno solo, gana la partida', end && end.kind === 'abandon' && u.phase === 'over' && u.winnerTeam === 0);
  ok('en parejas nadie "sale" de la mesa (lo reemplaza la computadora)', E.drop(E.newMatch('parejas'), 1).length === 0);
}
{ // tríos con alguien que se va a mitad de partida: se puede terminar igual
  let bad = 0;
  for (let sd = 1; sd <= 300; sd++) {
    const st = E.newMatch('trio', { seed: sd, target: 100 }); let g = 0, gone = false;
    while (st.phase !== 'over' && g++ < 400) {
      if (st.phase === 'idle' || st.phase === 'roundEnd') E.startRound(st);
      while (st.phase === 'pick') { const q = st.hands.findIndex((h, i) => !st.out[i] && h.length < 7); E.pick(st, q, E.botPick(st)); }
      if (!gone && st.round === 2 && st.chain.length === 3) { E.drop(st, sd % 3); gone = true; }
      if (st.phase !== 'play') continue;
      const q = st.turn, m = E.botMove(st, q); if (m) E.play(st, q, m.id, m.end); else E.pass(st, q);
    }
    if (st.phase !== 'over' || st.out[st.winnerTeam]) bad++;
  }
  ok('300 partidas de tríos donde alguien se va: todas terminan con un ganador que sigue en la mesa', bad === 0, bad);
}
console.log(fails ? `\n${fails} con fallas` : '\nTodo bien');
process.exit(fails ? 1 : 0);
