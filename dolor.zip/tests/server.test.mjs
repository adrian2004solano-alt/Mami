// Pruebas del servidor: varias personas conectadas a la vez (chat, mesas 1 vs 1 y parejas, salas privadas, monedas, soporte, admin).
// Uso: node tests/server.test.mjs            (con SQLite)
//      SUPABASE_URL=… SUPABASE_SECRET_KEY=… node tests/server.test.mjs   (contra Supabase o el simulador tests/supabase-sim.mjs)
import { spawn } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const PORT = 5288, BASE = `http://localhost:${PORT}`, WSURL = `ws://localhost:${PORT}/ws`;
const dataDir = mkdtempSync(join(tmpdir(), 'domino-test-'));
let fails = 0, passes = 0;
const ok = (n, c, x = '') => { if (c) { passes++; console.log('  ✔', n); } else { fails++; console.log('  ✘', n, x); } };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

let srv; const CODES = {};
function startServer() {
  srv = spawn(process.execPath, ['--no-warnings', 'server/index.js'], { cwd: root, env: { ...process.env, PORT: String(PORT), DATA_DIR: dataDir, QUEUE_WAIT_MS: '1500', TIME_SCALE: '0.03', ADMIN_KEY: 'clave-de-prueba', GUEST_PER_HOUR: '1000', STAKES: '10,20,40,80', START_COINS: '500', DAILY_COINS: '100', RESCUE_COINS: '50', MONEY_BOTS: '1', MONEY_NEEDS_ACCOUNT: '0', PLAY_NEEDS_ACCOUNT: '0', DEPOSIT_MIN: '10', WITHDRAW_MIN: '10' }, stdio: ['ignore', 'pipe', 'pipe'] });
  srv.stderr.on('data', (d) => process.stderr.write('[srv] ' + d));
  srv.stdout.on('data', (d) => { for (const m of String(d).matchAll(/código para (\S+): (\d{6})/g)) CODES[m[1]] = m[2]; });
  return new Promise((r) => srv.stdout.on('data', (d) => { if (String(d).includes('http://localhost')) r(); }));
}
async function api(path, body, token, admin) {
  const res = await fetch(BASE + path, { method: body ? 'POST' : 'GET', headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}), ...(admin ? { 'X-Admin-Key': admin } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: res.status, ...(await res.json()) };
}

// Un jugador conectado que juega solo (toma fichas y juega la primera jugada posible)
class Player {
  constructor(name) { this.name = name; this.msgs = []; this.waiters = []; this.free = new Set(); this.mine = 0; }
  async connect(token) {
    if (!token) { const g = await api('/api/guest', {}); token = g.token; this.me = g.me; }
    this.token = token;
    this.ws = new WebSocket(WSURL);
    await new Promise((r, j) => { this.ws.onopen = r; this.ws.onerror = j; });
    this.ws.onmessage = (e) => this.onMsg(JSON.parse(e.data));
    this.send({ t: 'hello', token });
    const w = await this.wait((m) => m.t === 'welcome');
    this.me = w.me; return this;
  }
  send(m) { this.ws.send(JSON.stringify(m)); }
  wait(pred, ms = 20000) {
    const hit = this.msgs.find(pred); if (hit) { this.msgs.splice(this.msgs.indexOf(hit), 1); return Promise.resolve(hit); }
    return new Promise((res, rej) => { const w = { pred, res }; this.waiters.push(w); setTimeout(() => { this.waiters = this.waiters.filter((x) => x !== w); rej(new Error(this.name + ': tiempo agotado')); }, ms); });
  }
  onMsg(m) {
    if (m.t === 'ev') for (const e of m.e) this.onEv(e);
    if (m.t === 'matched') { this.view = m.view; this.seat = m.view.me; this.free = new Set(m.view.deck.map((o, i) => (o < 0 ? i : -1)).filter((i) => i >= 0)); this.mine = m.view.hand.length; if (m.view.phase === 'pick') this.pickLoop(); }
    const w = this.waiters.find((x) => x.pred(m));
    if (w) { this.waiters = this.waiters.filter((x) => x !== w); w.res(m); } else this.msgs.push(m);
  }
  onEv(e) {
    if (this.leaveAfter && e.type === 'turn') { this.send({ t: 'leave' }); this.leaveAfter = false; this.autoplay = false; }
    if (e.type === 'round') { this.free = new Set([...Array(28).keys()]); this.mine = 0; this.events = (this.events || 0) + 1; setTimeout(() => this.pickLoop(), 150); }
    if (e.type === 'pick') { this.free.delete(e.i); if (e.p === this.seat) this.mine++; }
    if (e.type === 'pozo') for (const i of e.idx) this.free.delete(i);
    if (e.type === 'turn' && e.p === this.seat && this.autoplay !== false) {
      setTimeout(() => { if (e.legal && e.legal.length) this.send({ t: 'act', a: { t: 'play', tile: e.legal[0].id, end: e.legal[0].end } }); else this.send({ t: 'act', a: { t: 'pass' } }); }, 20);
    }
  }
  pickLoop() {
    if (this.mine >= 7 || !this.free.size) return;
    const arr = [...this.free], i = arr[Math.floor(Math.random() * arr.length)];
    this.send({ t: 'act', a: { t: 'pick', i } });
    setTimeout(() => this.pickLoop(), 60);
  }
  close() { this.ws.close(); }
}

try {
  await startServer();
  console.log('Cuentas');
  const A = await new Player('A').connect(), B = await new Player('B').connect();
  ok('cuenta de invitado con 500 monedas de bienvenida', A.me.coins === 500 && /^Jugador\d+/.test(A.me.name));
  const minor = await api('/api/register', { name: 'Yoel Prueba', email: 'Yoel@Ejemplo.com', password: 'secreto123' }, A.token);
  ok('sin confirmar 18+ no se registra', minor.status === 400 && /18/.test(minor.error));
  const reg = await api('/api/register', { name: 'Yoel Prueba', email: 'Yoel@Ejemplo.com', password: 'secreto123', adult: true }, A.token);
  await sleep(200);
  ok('registro con correo: se envía un código de 6 números', reg.pending && reg.email === 'yoel@ejemplo.com' && /^\d{6}$/.test(CODES['yoel@ejemplo.com'] || ''), JSON.stringify(reg));
  const wrong = await api('/api/register/verify', { code: '000000' === CODES['yoel@ejemplo.com'] ? '111111' : '000000' }, A.token);
  const ver = await api('/api/register/verify', { code: CODES['yoel@ejemplo.com'] }, A.token);
  ok('con el código correcto la cuenta queda registrada (y con uno malo no)', wrong.status === 400 && ver.me && ver.me.registered && ver.me.name === 'Yoel Prueba' && ver.me.email === 'yoel@ejemplo.com');
  const dup = await api('/api/register', { name: 'yoel prueba', email: 'otro@ejemplo.com', password: 'otraclave', adult: true }, B.token);
  const dupMail = await api('/api/register', { name: 'Otro Nombre', email: 'yoel@ejemplo.com', password: 'otraclave', adult: true }, B.token);
  ok('no se repiten nombres ni correos', dup.status === 400 && dupMail.status === 400 && /correo/.test(dupMail.error));
  const bad = await api('/api/profile', { name: 'Pendejo' }, B.token);
  ok('nombres groseros no', bad.status === 400);
  const lg = await api('/api/login', { name: 'yoel@ejemplo.com', password: 'secreto123' });
  const lgBad = await api('/api/login', { name: 'Yoel Prueba', password: 'mala' });
  ok('entrar con correo y contraseña', !!lg.token && lgBad.status === 400);
  const daily = await api('/api/daily', {}, A.token), daily2 = await api('/api/daily', {}, A.token);
  ok('bono diario una vez al día (+100)', daily.coins === 600 && daily2.status === 400);
  const prof = await api('/api/profile', { avatar: 's1.h2.c3.t1.g0.b2.k5', prefs: { felt: 'verde', wood: 'caoba', tiles: 'negro', pips: 'colores' } }, B.token);
  ok('guardar avatar (gratis); los estilos de pago no se aplican sin comprarlos', prof.me.avatar === 's1.h2.c3.t1.g0.b2.k5' && prof.me.prefs.felt === 'bandera' && prof.me.prefs.tiles === 'marfil');

  console.log('Chat');
  A.send({ t: 'chat', text: 'Hola mierda, entren a www.estafa.com' });
  const ch = await B.wait((m) => m.t === 'chat');
  ok('el mensaje llega a los demás, sin groserías ni enlaces', ch.m.text.includes('Hola') && !/mierda/i.test(ch.m.text) && ch.m.text.includes('[enlace]'), ch.m.text);
  for (let i = 0; i < 7; i++) A.send({ t: 'chat', text: 'spam ' + i });
  const err = await A.wait((m) => m.t === 'error');
  ok('límite de mensajes seguidos', /rápido/.test(err.msg));
  B.send({ t: 'report', id: ch.m.id });
  ok('reportar un mensaje', !!(await B.wait((m) => m.t === 'notice' && m.kind === 'report')));

  console.log('Mesa 1 vs 1 (dos personas)');
  const coinsA0 = (await api('/api/me', null, A.token)).me.coins, coinsB0 = (await api('/api/me', null, B.token)).me.coins;
  A.send({ t: 'queue', mode: 'duelo', stake: 20 }); B.send({ t: 'queue', mode: 'duelo', stake: 20 });
  const [mA, mB] = await Promise.all([A.wait((m) => m.t === 'matched'), B.wait((m) => m.t === 'matched')]);
  ok('se juntan en la misma mesa', mA.view.room.id === mB.view.room.id && mA.view.seats.every((s) => !s.bot));
  ok('se cobra la apuesta', (await A.wait((m) => m.t === 'coins' && m.reason === 'apuesta')).coins === coinsA0 - 20);
  A.send({ t: 'chat', scope: 'mesa', text: '¡Buena suerte!' });
  ok('chat de la mesa', (await B.wait((m) => m.t === 'tchat')).text === '¡Buena suerte!');
  const [eA] = await Promise.all([A.wait((m) => m.t === 'end', 120000), B.wait((m) => m.t === 'end', 120000)]);
  await sleep(300);
  const fA = (await api('/api/me', null, A.token)).me.coins, fB = (await api('/api/me', null, B.token)).me.coins;
  const winA = eA.info.winnerTeam === eA.info.players.find((p) => p.seat === A.seat).team;
  ok('la partida termina y el ganador cobra el pozo menos 10% (36 de 40)', (winA ? fA === coinsA0 + 16 && fB === coinsB0 - 20 : fB === coinsB0 + 16 && fA === coinsA0 - 20), JSON.stringify({ coinsA0, coinsB0, fA, fB, winA, scores: eA.info.scores }));
  const hist = await api('/api/history', null, winA ? A.token : B.token);
  ok('historial de monedas', hist.items.some((x) => x.reason === 'premio' && x.delta === 36));
  const revn = await api('/api/admin/revenue', null, null, 'clave-de-prueba');
  ok('rentabilidad: 10% de comisión (4 de 40)', revn.total.fee === 4 && revn.total.collected === 40 && revn.total.paid === 36 && revn.fee === 0.1, JSON.stringify(revn.total));
  console.log('Partida gratis');
  const fa0 = (await api('/api/me', null, A.token)).me.coins;
  A.send({ t: 'queue', mode: 'duelo', stake: 0, target: 100 }); B.send({ t: 'queue', mode: 'duelo', stake: 0, target: 100 });
  const [gA] = await Promise.all([A.wait((m) => m.t === 'matched'), B.wait((m) => m.t === 'matched')]);
  ok('gratis: se juntan sin cobrar', gA.view.room.stake === 0);
  await Promise.all([A.wait((m) => m.t === 'end', 120000), B.wait((m) => m.t === 'end', 120000)]);
  await sleep(300);
  ok('gratis: nadie gana ni pierde monedas', (await api('/api/me', null, A.token)).me.coins === fa0);

  console.log('Parejas con la computadora');
  const C = await new Player('C').connect();
  C.send({ t: 'queue', mode: 'parejas', stake: 10 });
  const mC = await C.wait((m) => m.t === 'matched', 8000);
  ok('si no hay gente, se completa con jugadores de la computadora', mC.view.seats.filter((s) => s.bot).length === 3 && mC.view.n === 4);
  const eC = await C.wait((m) => m.t === 'end', 120000);
  ok('partida de parejas completa hasta 200', Math.max(...eC.info.scores) >= 200, JSON.stringify(eC.info.scores));

  console.log('Tríos (partida rápida a 100)');
  const T1 = await new Player('T1').connect(), T2 = await new Player('T2').connect();
  T1.send({ t: 'queue', mode: 'trio', stake: 10, target: 100 }); T2.send({ t: 'queue', mode: 'trio', stake: 10, target: 100 });
  const [t1m] = await Promise.all([T1.wait((m) => m.t === 'matched', 8000), T2.wait((m) => m.t === 'matched', 8000)]);
  ok('tríos: dos personas y un BOT en la misma mesa, a 100', t1m.view.n === 3 && t1m.view.seats.filter((x) => x.bot).length === 1 && t1m.view.target === 100 && t1m.view.scores.length === 3);
  T2.leaveAfter = true;
  const outEv = await T1.wait((m) => m.t === 'ev' && m.e.some((e) => e.type === 'out'), 30000);
  ok('tríos: si alguien se va, la partida sigue sin él', !!outEv);
  const tEnd = await T1.wait((m) => m.t === 'end', 120000);
  await sleep(300);
  const t1c = (await api('/api/me', null, T1.token)).me.coins, t1won = tEnd.info.winnerTeam === T1.seat;
  ok('tríos: termina a 100 y el ganador cobra el triple menos 10% (27)', Math.max(...tEnd.info.scores) >= 100 && (t1won ? t1c === 500 - 10 + 27 : t1c === 490) && tEnd.info.prize === 27, JSON.stringify({ t1c, t1won, s: tEnd.info.scores }));
  ok('tríos: quien se fue pierde su monto', (await api('/api/me', null, T2.token)).me.coins === 490);

  console.log('Abandonar y reconectar');
  const D = await new Player('D').connect(), E2 = await new Player('E').connect();
  D.send({ t: 'queue', mode: 'duelo', stake: 40 }); E2.send({ t: 'queue', mode: 'duelo', stake: 40 });
  await Promise.all([D.wait((m) => m.t === 'matched'), E2.wait((m) => m.t === 'matched')]);
  D.close(); await sleep(400);
  const D2 = await new Player('D2').connect(D.token);
  const back = await D2.wait((m) => m.t === 'matched' && m.resume, 5000);
  ok('al volver a entrar retomas tu mesa', back.view.room.id && back.view.hand.length >= 0);
  D2.autoplay = false; D2.send({ t: 'leave' });
  ok('abandonar la mesa', !!(await D2.wait((m) => m.t === 'left')));
  const eE = await E2.wait((m) => m.t === 'end', 120000);
  ok('la mesa sigue con la computadora en lugar de quien se fue', eE.info.players.some((p) => p.left));
  const dCoins = (await api('/api/me', null, D.token)).me.coins;
  ok('quien abandona pierde su apuesta', dCoins === 500 - 40, dCoins);

  console.log('Salas privadas (invitación por código y enlace)');
  const G = await new Player('G').connect(), H = await new Player('H').connect(), J = await new Player('J').connect();
  G.send({ t: 'sala_crear', mode: 'parejas', stake: 20 });
  const s1 = (await G.wait((m) => m.t === 'sala' && m.sala)).sala;
  ok('crear una sala da un código de 6 letras', /^[A-Z2-9]{6}$/.test(s1.code) && s1.host === G.me.id && s1.seats[0].uid === G.me.id && s1.n === 4, JSON.stringify(s1));
  const info = await api('/api/salas/' + s1.code.toLowerCase());
  ok('el enlace muestra de qué es la sala', info.sala && info.sala.mode === 'parejas' && info.sala.stake === 20 && info.sala.players === 1);
  ok('un código que no existe', (await api('/api/salas/ZZZZZZ')).status === 404);
  J.send({ t: 'sala_unirse', code: 'NOEXIS' });
  ok('unirse con un código malo avisa', (await J.wait((m) => m.t === 'error' && m.code === 'sala')).msg.includes('no existe'));
  H.send({ t: 'sala_unirse', code: s1.code.slice(0, 3).toLowerCase() + '-' + s1.code.slice(3).toLowerCase() });
  const s2 = (await H.wait((m) => m.t === 'sala' && m.sala)).sala;
  ok('unirse con el código (aunque lo escriban en minúscula o con guion)', s2.code === s1.code && s2.seats.filter(Boolean).length === 2);
  ok('el anfitrión se entera de que alguien entró', !!(await G.wait((m) => m.t === 'notice' && m.kind === 'sala')));
  H.send({ t: 'sala_asiento', seat: 2 });
  const s3 = (await G.wait((m) => m.t === 'sala' && m.sala && m.sala.seats[2] && m.sala.seats[2].uid === H.me.id)).sala;
  ok('elegir asiento (sentarse de pareja)', s3.seats[1] === null);
  H.send({ t: 'sala_iniciar' });
  ok('solo el anfitrión puede empezar', /anfitrión/.test((await H.wait((m) => m.t === 'error')).msg));
  G.send({ t: 'sala_config', stake: 40 });
  ok('el anfitrión cambia el monto', (await H.wait((m) => m.t === 'sala' && m.sala && m.sala.stake === 40)).sala.stake === 40);
  J.send({ t: 'sala_unirse', code: s1.code });
  await G.wait((m) => m.t === 'sala' && m.sala && m.sala.seats.filter(Boolean).length === 3);
  G.send({ t: 'sala_expulsar', uid: J.me.id });
  const kickedMsg = await J.wait((m) => m.t === 'sala' && m.sala === null && m.msg);
  J.send({ t: 'sala_unirse', code: s1.code });
  ok('sacar a alguien de la sala (y no puede volver)', /sacó/.test(kickedMsg.msg) && /No puedes entrar/.test((await J.wait((m) => m.t === 'error' && m.code === 'sala')).msg));
  const gc0 = (await api('/api/me', null, G.token)).me.coins;
  G.send({ t: 'sala_iniciar' });
  const [gm, hm] = await Promise.all([G.wait((m) => m.t === 'matched'), H.wait((m) => m.t === 'matched')]);
  ok('empezar: los dos en la misma mesa, de pareja, con 2 BOT', gm.view.room.id === hm.view.room.id && gm.view.me === 0 && hm.view.me === 2 && gm.view.seats.filter((x) => x.bot).length === 2 && gm.sala === s1.code);
  ok('se cobra el monto de la sala', (await G.wait((m) => m.t === 'coins' && m.reason === 'apuesta')).coins === gc0 - 40);
  await Promise.all([G.wait((m) => m.t === 'end', 120000), H.wait((m) => m.t === 'end', 120000)]);
  const rev = await G.wait((m) => m.t === 'sala' && m.sala && m.sala.state === 'espera', 8000);
  ok('al terminar, la sala queda lista para la revancha', rev.sala.code === s1.code && rev.sala.seats.filter(Boolean).length === 2);
  H.send({ t: 'sala_salir' });
  ok('salir de la sala', (await G.wait((m) => m.t === 'sala' && m.sala && m.sala.seats.filter(Boolean).length === 1)).sala.host === G.me.id);
  G.send({ t: 'sala_salir' });
  await G.wait((m) => m.t === 'sala' && m.sala === null);
  ok('la sala vacía se cierra', (await api('/api/salas/' + s1.code)).status === 404);

  console.log('Servicio al cliente y administración');
  const tk = await api('/api/tickets', { category: 'Monedas', subject: 'No me llegó el bono', text: 'Jugué ayer y no me dieron el bono diario.' }, B.token);
  ok('crear una consulta', tk.id > 0);
  const noKey = await api('/api/admin/stats', null, null, 'mala');
  ok('el panel pide la clave', noKey.status === 401);
  const st = await api('/api/admin/stats', null, null, 'clave-de-prueba');
  ok('estadísticas del panel', st.users >= 5 && st.openTickets >= 1 && st.openReports >= 1, JSON.stringify(st));
  await api(`/api/admin/tickets/${tk.id}/reply`, { text: 'Ya te los acreditamos. ¡Suerte!' }, null, 'clave-de-prueba');
  const note = await B.wait((m) => m.t === 'notice' && m.kind === 'ticket');
  const th = await api(`/api/tickets/${tk.id}`, null, B.token);
  ok('la respuesta de soporte llega al jugador', !!note && th.messages.length === 2 && !!th.messages[1].admin && th.ticket.status === 'respondido');
  const adj = await api(`/api/admin/users/${B.me.id}/coins`, { delta: 100, reason: 'bono' }, null, 'clave-de-prueba');
  ok('ajustar monedas desde el panel', adj.coins > 0 && (await B.wait((m) => m.t === 'coins' && m.reason === 'ajuste de soporte')).delta === 100);
  await api(`/api/admin/users/${B.me.id}/mute`, { minutes: 10 }, null, 'clave-de-prueba');
  B.send({ t: 'chat', text: 'hola' });
  ok('silenciar a un jugador', /No puedes escribir/.test((await B.wait((m) => m.t === 'error')).msg));
  const lb = await api('/api/leaderboard'), lbm = await api('/api/leaderboard?by=money');
  ok('ranking por ganadas y por lo más ganado (sin saldos)', lb.items.length >= 2 && lbm.items.length >= 1 && lbm.items[0].won > 0 && !('coins' in lb.items[0]));

  console.log('Billetera y tienda');
  const a0 = (await api('/api/me', null, A.token)).me.coins;
  const noReg = await api('/api/wallet/recargar', { amount: 500, method: 'PayPal', details: 'ref 1' }, C.token);
  ok('sin registrarse no se usa la billetera', noReg.status === 403);
  const dep = await api('/api/wallet/recargar', { amount: 500, method: 'Transferencia bancaria', details: 'Ref 778899' }, A.token);
  const pend = await api('/api/admin/pays?estado=pendiente', null, null, 'clave-de-prueba');
  ok('pedir una recarga: le llega al admin', dep.id > 0 && pend.items.some((x) => x.id === dep.id && x.kind === 'deposit' && x.amount === 500));
  await api('/api/admin/pays/' + dep.id, { approve: true }, null, 'clave-de-prueba');
  ok('el admin la aprueba y se acredita el saldo', (await A.wait((m) => m.t === 'coins' && m.reason === 'recarga')).coins === a0 + 500);
  const wd = await api('/api/wallet/retirar', { amount: 300, method: 'PayPal', details: 'yo@paypal.com' }, A.token);
  const wd2 = await api('/api/wallet/retirar', { amount: 10, method: 'PayPal', details: 'yo@paypal.com' }, A.token);
  ok('pedir un retiro aparta el saldo (y solo uno a la vez)', wd.coins === a0 + 200 && wd2.status === 400);
  await api('/api/admin/pays/' + wd.id, { approve: false, note: 'Datos incompletos' }, null, 'clave-de-prueba');
  ok('si el admin rechaza el retiro, se devuelve', (await A.wait((m) => m.t === 'coins' && m.reason === 'retiro')).coins === a0 + 500);
  const unowned = await api('/api/profile', { prefs: { felt: 'verde' } }, A.token);
  ok('no se puede usar un estilo sin comprarlo', unowned.me.prefs.felt === 'bandera');
  const buy = await api('/api/shop/buy', { cat: 'felt', key: 'verde' }, A.token);
  const use = await api('/api/profile', { prefs: { felt: 'verde' } }, A.token);
  ok('comprar en la tienda (99) y usarlo', buy.me && buy.me.owned.includes('felt:verde') && buy.me.coins === a0 + 500 - 99 && use.me.prefs.felt === 'verde');
  const again2 = await api('/api/shop/buy', { cat: 'felt', key: 'verde' }, A.token);
  const rv = await api('/api/admin/revenue', null, null, 'clave-de-prueba');
  ok('no se compra dos veces y la venta sale en rentabilidad', again2.status === 400 && rv.shop.amount === 99 && rv.wallet.deposits === 500);

  console.log('Reinicio con una partida a medias');
  const F = await new Player('F').connect();
  F.autoplay = false;
  F.send({ t: 'queue', mode: 'duelo', stake: 80 });
  await F.wait((m) => m.t === 'matched', 8000);
  const fBefore = (await api('/api/me', null, F.token)).me.coins;
  srv.kill('SIGTERM'); await sleep(800); await startServer();
  const fAfter = (await api('/api/me', null, F.token)).me.coins;
  ok('se devuelve la apuesta de la partida interrumpida', fBefore === 420 && fAfter === 500, fBefore + ' → ' + fAfter);

  console.log('Sitio');
  for (const [p, code] of [['/', 200], ['/reglas', 200], ['/server/hub.js', 404], ['/supabase/migrations/001_domino.sql', 404], ['/data/domino.db', 404], ['/../package.json', 404], ['/shared/engine.js', 200]]) {
    const r = await fetch(BASE + p); ok(`${p} → ${code}`, r.status === code, r.status);
  }
  for (const pl of [A, B, C, D2, E2, F, G, H, J, T1, T2]) try { pl.close(); } catch {}
} catch (e) { fails++; console.error('ERROR', e); }
finally { srv.kill('SIGTERM'); await sleep(300); rmSync(dataDir, { recursive: true, force: true }); }
console.log(`\n${passes} bien, ${fails} con fallas`);
process.exit(fails ? 1 : 0);
