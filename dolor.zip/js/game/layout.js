// Dominó Dominicano · game/layout.js
// Colocación de la cola: recto/giro, dobles atravesados y centrados, sin choques (con búsqueda con retroceso).
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- lógica de colocación en cadena (arranca en vertical, como en el video) ----
function geom(x,y,dx,dy,dbl){
 if(dbl)return{cx:x+dx*W/2,cy:y+dy*W/2,ang:Math.atan2(dy,dx)+Math.PI/2,nx:x+dx*W,ny:y+dy*W};
 return{cx:x+dx*L/2,cy:y+dy*L/2,ang:Math.atan2(dy,dx),nx:x+dx*L,ny:y+dy*L}}
const ext=ang=>[Math.abs(Math.cos(ang))*L/2+Math.abs(Math.sin(ang))*W/2,Math.abs(Math.sin(ang))*L/2+Math.abs(Math.cos(ang))*W/2];
// Cola en doble espiral: las dos puntas giran SIEMPRE en el mismo sentido horario (una sube y dobla a la derecha,
// la otra baja y dobla a la izquierda). Quedan simétricas por punto y nunca se cruzan ni chocan.
const BM=24; // margen interior de la mesa
function hits(cx,cy,ang){const[hx,hy]=ext(ang);return chain.some(t=>{const[tx,ty]=ext(t.ang);return Math.abs(t.x-cx)<hx+tx-2&&Math.abs(t.y-cy)<hy+ty-2})}
const inside=(cx,cy,ang)=>{const[hx,hy]=ext(ang);return Math.abs(cx)+hx<=BW/2-BM+.5&&cy-hy>=BM-.5&&cy+hy<=BH-BM+.5};
// Reserva: mientras la otra punta siga en el eje central (su tramo recto inicial), esa columna se le guarda para que
// ésta no se la tape al dar la vuelta a la mesa.
let PH=null;
const colRes=n=>{const e=ends[n];if(!e||Math.abs(e.x)>1||e.dx!==0)return null;return n==='L'?{y0:BM,y1:e.y}:{y0:e.y,y1:BH-BM}};
function hitsPH(cx,cy,ang){if(!PH||PH.y1-PH.y0<2)return false;const[hx,hy]=ext(ang),hh=(PH.y1-PH.y0)/2,my=(PH.y0+PH.y1)/2;return Math.abs(cx)<hx+L/2-2&&Math.abs(cy-my)<hy+hh-2}
const free=(cx,cy,ang)=>inside(cx,cy,ang)&&!hits(cx,cy,ang)&&!hitsPH(cx,cy,ang);
// candidato: 's' = seguir recto (el doble va atravesado), 't' = girar 90° hacia pd
function cand(end,mode,dbl,pd,force){
 if(mode==='s'){const g=geom(end.x,end.y,end.dx,end.dy,dbl);g.dx=end.dx;g.dy=end.dy;g.dbl=dbl;return g}
 // 'i': doble en línea (acostado a lo largo de una cola horizontal), siempre se ve horizontal
 if(mode==='i'){const g=geom(end.x,end.y,end.dx,end.dy,false);g.dx=end.dx;g.dy=end.dy;g.dbl=false;g.inl=true;return g}
 // REGLA: nunca se dobla por el lado de un doble; la curva solo sale del extremo de una ficha normal
 // (force = último recurso cuando la mesa ya no deja otra salida: la ficha sale centrada por la punta del doble)
 if(end.dbl&&!end.dbl.inl&&!force)return null; // (un doble acostado en línea gira por su punta, como una ficha normal)
 const px=pd[0],py=pd[1],T=end.dbl&&!end.dbl.inl?{x:end.dbl.cx+px*L/2,y:end.dbl.cy+py*L/2}:{x:end.x+end.dx*W/2-px*W/2,y:end.y+end.dy*W/2-py*W/2};
 const g=geom(T.x,T.y,px,py,false);g.dx=px;g.dy=py;g.dbl=false;return g}
const endOf=g=>({x:g.nx,y:g.ny,dx:g.dx,dy:g.dy,dbl:g.dbl||g.inl?{cx:g.cx,cy:g.cy,inl:!!g.inl}:null});
// ¿después de poner g queda espacio para seguir (recto o girando)? Evita que una punta se meta en un callejón sin salida
// (mira 2 fichas hacia adelante, porque tras un doble hay que seguir recto antes de poder doblar)
// strict: además exige que pueda venir un DOBLE a continuación, atravesado y centrado, y que la ficha que le sigue
// pueda salir recta del medio del doble. Así un doble nunca se queda pegado al borde ni en una esquina.
// REGLA DEL DOMINÓ: el doble SIEMPRE va atravesado (en cruz) a la cola, en cualquier dirección, como en la mesa real.
const needCross=e=>true;
function dsafe(e){const q=cand(e,'s',true);if(!free(q.cx,q.cy,q.ang))return false;
 chain.push({x:q.cx,y:q.cy,ang:q.ang});let pushed=1;
 try{const n=cand(endOf(q),'s',false);if(!free(n.cx,n.cy,n.ang))return false;
  chain.push({x:n.cx,y:n.cy,ang:n.ang});pushed++;const e2=endOf(n);
  return[['s',0],['t',[-e2.dy,e2.dx]],['t',[e2.dy,-e2.dx]]].some(([m,p])=>{const z=cand(e2,m,false,p);return z&&free(z.cx,z.cy,z.ang)})}
 finally{while(pushed--)chain.pop()}}
// ¿ya se jugó el doble n|n? Entonces en una punta con n no hace falta guardarle espacio
const dblDone=n=>n!==undefined&&chain.some(t=>t.t&&t.t.a===n&&t.t.b===n);
function room(g,depth=2,strict=true,open){chain.push({x:g.cx,y:g.cy,ang:g.ang});const e=endOf(g);let ok=false;
 try{ok=(!strict||dblDone(open)||dsafe(e))&&[['s',0],['t',[-e.dy,e.dx]],['t',[e.dy,-e.dx]]].some(([m,p])=>{const q=cand(e,m,false,p);return q&&free(q.cx,q.cy,q.ang)&&(depth<=1||room(q,depth-1,strict))})}finally{chain.pop()}
 return ok}
// Simula (sin tocar la mesa) cuántas fichas normales más caben siguiendo la regla recto/giro desde un extremo.
function roll(end,steps,pushed){let e=end,n=0;
 for(;n<steps;n++){let q=null;
  for(const[m,p]of[['s',0],['t',[-e.dy,e.dx]],['t',[e.dy,-e.dx]]]){const g=cand(e,m,false,p);if(g&&free(g.cx,g.cy,g.ang)&&room(g,1,false)){q=g;break}}
  if(!q)break;chain.push({x:q.cx,y:q.cy,ang:q.ang});pushed.push(1);e=endOf(q)}
 return n}
function future(g,other){const pushed=[];chain.push({x:g.cx,y:g.cy,ang:g.ang});pushed.push(1);
 const a=roll(endOf(g),6,pushed),b=roll(other,6,pushed);while(pushed.length)pushed.pop(),chain.pop();
 return Math.min(a,b)*10+a+b}
const PSTAT={bad:0,fixed:0};let chainVer=0,centerEnds=null;const RPC=new Map();
// Replanifica un brazo entero (sus fichas ya puestas + la nueva) buscando un acomodo sin choques: recto, giro, giro,
// con retroceso. Las fichas ya puestas se deslizan suavemente a su nuevo lugar.
function replanArm(name,newTile,p1,p2){
 if(!centerEnds)return null;
 const key=newTile?chainVer+'|'+name+'|'+newTile.a+','+newTile.b:null;if(key&&RPC.has(key))return RPC.get(key);
 const arm=chain.filter(t=>t.arm===name),seq=arm.map(t=>({t:t.t,p2:t.p2,tile:t}));if(newTile)seq.push({t:newTile,p2,tile:null});
 const saved=chain,savedPH=PH;chain=chain.filter(t=>t.arm!==name);PH=null;let out=null;
 try{
  for(const M of[BM,12,4]){let nodes=0;const res=[];
   const dfs=(i,end)=>{if(i===seq.length)return true;if(++nodes>200000)return false;
    const sq=seq[i],isD=sq.t.a===sq.t.b,cw=[-end.dy,end.dx],ccw=[end.dy,-end.dx],opts=[];
    if(isD)opts.push(['s',true,0]);
    else{opts.push(['s',false,0],['t',false,cw],['t',false,ccw]);if(end.dbl)opts.push(['t',false,cw,true],['t',false,ccw,true])}
    for(const[m,d,p,fo]of opts){const g=cand(end,m,d,p,fo);if(!g)continue;const[hx,hy]=ext(g.ang);
     if(!(Math.abs(g.cx)+hx<=BW/2-M+.5&&g.cy-hy>=M-.5&&g.cy+hy<=BH-M+.5)||hits(g.cx,g.cy,g.ang))continue;
     chain.push({x:g.cx,y:g.cy,ang:g.ang});res[i]=g;
     if(dfs(i+1,{x:g.nx,y:g.ny,dx:g.dx,dy:g.dy,open:sq.p2,dbl:g.dbl||g.inl?{cx:g.cx,cy:g.cy,inl:!!g.inl}:null}))return true;
     chain.pop()}
    return false};
   if(dfs(0,Object.assign({},centerEnds[name]))){out={res:res.slice(),arm};break}}
 }finally{chain=saved;PH=savedPH}
 if(key)RPC.set(key,out);return out}
// Si giras el teléfono (o cambia el tamaño de la pantalla) cambia el eje de los dobles: se vuelve a acomodar toda la cola.
function relayoutAll(){
 const c0=chain.find(t=>t.arm==='C');if(!c0||!centerEnds)return;
 chainVer++;RPC.clear();
 const sl=centerSlot(c0.t);
 c0.mv={t0:now,fx:c0.x,fy:c0.y,fa:c0.ang};c0.x=sl.pl.x;c0.y=sl.pl.y;c0.ang=sl.pl.ang;c0.dbl=sl.pl.dbl;
 centerEnds={L:Object.assign({},sl.ends.L),R:Object.assign({},sl.ends.R)};
 for(const n of['L','R']){
  const rp=replanArm(n,null);
  if(!rp){ends[n]=Object.assign({},centerEnds[n],{tile:c0});continue}
  let last=null;rp.arm.forEach((tl,i)=>{const g=rp.res[i];tl.mv={t0:now,fx:tl.x,fy:tl.y,fa:tl.ang};tl.x=g.cx;tl.y=g.cy;tl.ang=g.ang;tl.dbl=g.dbl;last=[tl,g]});
  if(last){const[tl,g]=last;ends[n]={x:g.nx,y:g.ny,dx:g.dx,dy:g.dy,open:tl.p2,dbl:g.dbl||g.inl?{cx:g.cx,cy:g.cy,inl:!!g.inl}:null,tile:tl}}
  else ends[n]=Object.assign({},centerEnds[n],{tile:c0})}}
function place(end,t,name){
 const p1=end.open,p2=t.a===p1?t.b:t.a,isD=t.a===t.b;
 PH=colRes(name==='L'?'R':'L');
 const cw=[-end.dy,end.dx],ccw=[end.dy,-end.dx],opts=[];
 // REGLA: el doble SIEMPRE va atravesado (en cruz) y CENTRADO en la ficha anterior: medio a medio, nunca en una esquina
 if(isD)opts.push(['s',true,0]);
 else opts.push(['s',false,0],['t',false,cw],['t',false,ccw]); // preferencia: recto, giro horario, giro antihorario
 let pick=null,fb=null;
 const other=ends[name==='L'?'R':name==='R'?'L':null];
 for(const strict of[true,false]){const oks=[];
  for(const[m,d,p]of opts){const g=cand(end,m,d,p);if(!g||!free(g.cx,g.cy,g.ang))continue;if(!fb)fb=g;if(room(g,2,strict,isD?undefined:p2))oks.push(g)}
  if(oks.length){pick=oks[0];
   if(oks.length>1&&other&&chain.length>=8){let bs=-1;for(const g of oks){const sc=future(g,other);if(sc>bs){bs=sc;pick=g}}} // elige la salida que deja más espacio a las dos puntas
   break}}
 PH=null;
 // mesa muy llena: se relaja primero la columna reservada y luego el margen del borde, siempre sin que choque con otra ficha
 const insM=(cx,cy,ang,m)=>{const[hx,hy]=ext(ang);return Math.abs(cx)+hx<=BW/2-m+.5&&cy-hy>=m-.5&&cy+hy<=BH-m+.5};
 if(!pick&&!fb)for(const m of[BM,10,3]){fb=opts.map(([mo,d,p])=>cand(end,mo,d,p)).filter(Boolean).find(q=>insM(q.cx,q.cy,q.ang,m)&&!hits(q.cx,q.cy,q.ang));if(fb)break}
 if(!pick&&!fb&&!isD)for(const m of[BM,10,3]){fb=[['s',false,0],['t',false,cw],['t',false,ccw]].map(([mo,d,p])=>cand(end,mo,d,p,true)).filter(Boolean).find(q=>insM(q.cx,q.cy,q.ang,m)&&!hits(q.cx,q.cy,q.ang));if(fb)break}
 const g=pick||fb||opts.map(([m,d,p])=>cand(end,m,d,p)).filter(Boolean).find(q=>inside(q.cx,q.cy,q.ang))||(isD?cand(end,'s',true):cand(end,'t',false,cw,true));
 // Si aun así la ficha chocaría (mesa casi llena), se vuelve a acomodar todo ese brazo de la cola con búsqueda con retroceso
 if((name==='L'||name==='R')&&(hits(g.cx,g.cy,g.ang)||!insM(g.cx,g.cy,g.ang,0))){
  const rp=replanArm(name,t,p1,p2);PSTAT.bad++;
  if(rp){const q=rp.res[rp.res.length-1];PSTAT.fixed++;
   return{x:q.cx,y:q.cy,ang:q.ang,p1,p2,dbl:q.dbl,t,rp,end:{x:q.nx,y:q.ny,dx:q.dx,dy:q.dy,open:p2,dbl:q.dbl||q.inl?{cx:q.cx,cy:q.cy,inl:!!q.inl}:null}}}}
 return{x:g.cx,y:g.cy,ang:g.ang,p1,p2,dbl:g.dbl,t,end:{x:g.nx,y:g.ny,dx:g.dx,dy:g.dy,open:p2,dbl:g.dbl||g.inl?{cx:g.cx,cy:g.cy,inl:!!g.inl}:null}}}
// primera ficha: la cola arranca vertical; si es un doble va atravesado (horizontal)
function centerSlot(t){const dbl=t.a===t.b,inl=false,h=(dbl&&!inl?W:L)/2,cy=BH/2,
  pl={x:0,y:cy,ang:dbl&&!inl?0:Math.PI/2,p1:t.a,p2:t.b,dbl,t},d=dbl?{cx:0,cy,inl}:null;
 return{name:'C',pl,ends:{L:{x:0,y:cy-h,dx:0,dy:-1,open:t.a,dbl:d&&Object.assign({},d)},R:{x:0,y:cy+h,dx:0,dy:1,open:t.b,dbl:d&&Object.assign({},d)}}}}
// dónde puedes poner una ficha: solo donde el motor dice que es jugada válida
function slots(t){const r=[];for(const m of legalNow)if(m.id===t.id)r.push(m.end==='C'||!chain.length?centerSlot(t):{name:m.end,pl:place(ends[m.end],t,m.end)});return r}
