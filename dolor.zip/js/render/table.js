// Dominó Dominicano · render/table.js
// Mesa estática (se dibuja una vez): bandera, marco, portavasos, vaso de ron, atril del jugador.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- bandera dominicana sobre toda la mesa (debajo de las fichas) ----
// tela de la mesa: trama fina para que la bandera se vea impresa sobre paño
const CLOTH=(()=>{const o=document.createElement('canvas');o.width=o.height=96;const g=o.getContext('2d');let sd=7;const R=()=>(sd=(sd*16807)%2147483647)/2147483647;
 for(let y=0;y<96;y+=2){g.fillStyle='rgba(0,0,0,'+(.05+R()*.04)+')';g.fillRect(0,y,96,1)}
 for(let x=0;x<96;x+=2){g.fillStyle='rgba(255,255,255,'+(.03+R()*.03)+')';g.fillRect(x,0,1,96)}
 for(let i=0;i<900;i++){g.fillStyle=R()<.5?'rgba(0,0,0,.10)':'rgba(255,255,255,.08)';g.fillRect(R()*96,R()*96,1,1)}
 return c.createPattern(o,'repeat')})();
// bandera dominicana cubriendo TODA la superficie de juego, sin escudo (la cruz blanca pasa por el centro, donde arranca la cola)
function flag(){
 if(PREFS.felt!=='bandera'&&FELTS[PREFS.felt])return felt(FELTS[PREFS.felt]);
 const m=30,x0=-BW/2-m,x1=BW/2+m,y0=-m,y1=BH+m,cy=BH/2,bw=78; // m: se mete debajo del marco
 const poly=(pts,fill)=>{c.beginPath();pts.forEach(([x,y],i)=>{const p=proj(x,y);i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y)});c.closePath();c.fillStyle=fill;c.fill()};
 const R=(xa,ya,xb,yb)=>[[xa,ya],[xb,ya],[xb,yb],[xa,yb]];
 poly(R(x0,y0,x1,y1),'#e8e6dd'); // blanco algo más apagado que el marfil de las fichas, para que se distingan
 poly(R(x0,y0,-bw/2,cy-bw/2),'#002d62');poly(R(bw/2,y0,x1,cy-bw/2),'#ce1126');
 poly(R(x0,cy+bw/2,-bw/2,y1),'#ce1126');poly(R(bw/2,cy+bw/2,x1,y1),'#002d62');
 // trama de tela y luz suave por encima
 c.fillStyle=CLOTH;c.fillRect(0,0,VW,VH)}
// paño de color liso (verde, azul o vino): tela con su trama, más clara bajo la lámpara y más oscura en las orillas
function felt(F){
 const m=30,pts=[[-BW/2-m,-m],[BW/2+m,-m],[BW/2+m,BH+m],[-BW/2-m,BH+m]].map(([x,y])=>proj(x,y));
 c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();c.fillStyle=F.base;c.fill();
 const P=proj(0,BH*.42);let g=c.createRadialGradient(P.x,P.y,30,P.x,P.y,620);g.addColorStop(0,F.hi);g.addColorStop(.55,F.base);g.addColorStop(1,F.lo);c.fillStyle=g;c.fill();
 c.fillStyle=CLOTH;c.fill();c.fillStyle=CLOTH;c.fill();
 // fibras sueltas del paño
 const R=mulberry(91);c.lineCap='round';for(let i=0;i<900;i++){const q=proj((R()-.5)*BW,R()*BH);c.beginPath();c.moveTo(q.x,q.y);c.lineTo(q.x+(R()-.5)*3,q.y+(R()-.5)*2);c.lineWidth=.6;c.strokeStyle=R()<.5?'rgba(255,255,255,.07)':'rgba(0,0,0,.12)';c.stroke()}c.lineCap='butt'}
// ---- mesa estática: se dibuja una sola vez en una imagen (así puede tener muchos detalles sin gastar rendimiento) ----
const SCS=2;let STATIC=null;
function inset(pathFn,blur,oy){ // sombra interior (el marco proyecta sombra sobre lo que tiene dentro)
 c.save();pathFn();c.clip();c.beginPath();c.rect(-400,-400,2400,1600);pathFn(true);
 c.shadowColor='#000d';c.shadowBlur=blur*SCS;c.shadowOffsetY=oy*SCS;c.fillStyle='#000';c.fill('evenodd');c.restore()}
// portavasos: vaso de acero inoxidable hundido en la mesa, con aro de madera torneada alrededor. En perspectiva:
// la boca es un óvalo; dentro se ve la pared del fondo (la que mira hacia ti) con reflejos cepillados y, más abajo,
// el fondo del vaso con su agujerito; el borde de adelante tapa parte del fondo y le hace sombra.
function cupHolder(x,y,r){const ry=r*.68,dp=r*.62;
 // aro de madera torneada (levemente elevado, con sombra)
 c.save();c.shadowColor='rgba(0,0,0,.6)';c.shadowBlur=7*SCS;c.shadowOffsetY=3*SCS;c.beginPath();c.ellipse(x,y+1,r+13,ry+10,0,0,7);c.fillStyle='#2a160a';c.fill();c.restore();
 c.beginPath();c.ellipse(x,y+2.5,r+13,ry+10,0,0,7);c.fillStyle='#1c0e05';c.fill();                              // canto del aro
 c.beginPath();c.ellipse(x,y,r+13,ry+10,0,0,7);c.fillStyle=woodAt(WOOD_BODY,.6,.45,x,y);c.fill();
 let g=c.createLinearGradient(0,y-ry-10,0,y+ry+10);g.addColorStop(0,'rgba(255,226,186,.32)');g.addColorStop(.45,'rgba(255,226,186,.02)');g.addColorStop(1,'rgba(0,0,0,.42)');c.fillStyle=g;c.fill();
 c.lineWidth=1;c.strokeStyle='rgba(0,0,0,.6)';c.stroke();
 c.beginPath();c.ellipse(x,y,r+12,ry+9,0,Math.PI*1.04,Math.PI*1.96);c.lineWidth=1.2;c.strokeStyle='rgba(255,230,192,.55)';c.stroke();   // brillo del canto
 c.beginPath();c.ellipse(x,y,r+7,ry+5,0,0,7);c.lineWidth=.8;c.strokeStyle='rgba(0,0,0,.35)';c.stroke();                                   // ranura del torneado
 // anillo de acero de la boca
 c.beginPath();c.ellipse(x,y,r+3.4,ry+2.6,0,0,7);g=c.createLinearGradient(x-r,y-ry,x+r*.6,y+ry);
 g.addColorStop(0,'#f6f8fa');g.addColorStop(.28,'#8a9198');g.addColorStop(.5,'#eef1f3');g.addColorStop(.75,'#5f666d');g.addColorStop(1,'#c4c9ce');c.fillStyle=g;c.fill();c.lineWidth=.8;c.strokeStyle='#1b1e21';c.stroke();
 // interior
 c.save();c.beginPath();c.ellipse(x,y,r,ry,0,0,7);c.clip();
 g=c.createLinearGradient(0,y-ry,0,y+ry*.4);g.addColorStop(0,'#d5d9dc');g.addColorStop(.3,'#8b9298');g.addColorStop(.7,'#40464b');g.addColorStop(1,'#202326');c.fillStyle=g;c.fillRect(x-r,y-ry,2*r,2*ry+2);   // pared del fondo
 {const R3=mulberry(Math.round(x*7+y));for(let i=0;i<30;i++){const a=Math.PI*(1.03+R3()*.94),x0=x+Math.cos(a)*r,y0=y+Math.sin(a)*ry,x1=x+Math.cos(a)*r*.82,y1=y+dp+Math.sin(a)*ry*.82;  // reflejos del acero cepillado
  c.beginPath();c.moveTo(x0,y0);c.lineTo(x1,y1);c.lineWidth=r*(.015+R3()*.06);c.strokeStyle=R3()<.55?'rgba(255,255,255,'+(.04+R3()*.14)+')':'rgba(0,0,0,'+(.04+R3()*.1)+')';c.stroke()}}
 const fx=x,fy=y+dp,fr=r*.82,fry=ry*.82;                                                                                     // fondo del vaso
 g=c.createRadialGradient(fx+fr*.15,fy-fry*.35,1,fx,fy,fr);g.addColorStop(0,'#868d93');g.addColorStop(.55,'#454b50');g.addColorStop(1,'#1d2023');
 c.beginPath();c.ellipse(fx,fy,fr,fry,0,0,7);c.fillStyle=g;c.fill();
 for(let i=0;i<5;i++){c.beginPath();c.ellipse(fx,fy,fr*(.25+i*.15),fry*(.25+i*.15),0,Math.PI*1.1,Math.PI*1.9);c.lineWidth=.6;c.strokeStyle='rgba(255,255,255,.08)';c.stroke()}  // marcas del torneado
 c.beginPath();c.ellipse(fx,fy,fr,fry,0,Math.PI*1.02,Math.PI*1.98);c.lineWidth=1.4;c.strokeStyle='rgba(255,255,255,.3)';c.stroke();   // canto del fondo
 c.beginPath();c.ellipse(fx,fy+fry*.08,r*.05,r*.035,0,0,7);c.fillStyle='#08090a';c.fill();                                   // agujerito
 g=c.createLinearGradient(0,y+ry*.15,0,y+ry);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.62)');c.fillStyle=g;c.fillRect(x-r,y,2*r,ry+1); // sombra del borde cercano
 g=c.createLinearGradient(0,y-ry,0,y-ry*.55);g.addColorStop(0,'rgba(0,0,0,.45)');g.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g;c.fillRect(x-r,y-ry,2*r,ry*.45); // sombra bajo el labio de atrás
 g=c.createRadialGradient(x+r*.28,y-ry*.4,1,x+r*.28,y-ry*.4,r*.45);g.addColorStop(0,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=g;c.fillRect(x-r,y-ry,2*r,2*ry); // brillo de la lámpara
 c.restore();
 c.beginPath();c.ellipse(x,y,r,ry,0,0,7);c.lineWidth=1.1;c.strokeStyle='rgba(0,0,0,.75)';c.stroke();                       // labio interior
 c.beginPath();c.ellipse(x,y,r+1.8,ry+1.4,0,Math.PI*.12,Math.PI*.88);c.lineWidth=1.2;c.strokeStyle='rgba(255,255,255,.85)';c.stroke()}
function chrome(x,y,r){
 let g=c.createLinearGradient(x-r,y-r,x+r,y+r);g.addColorStop(0,'#f7f9fb');g.addColorStop(.35,'#9aa1a8');g.addColorStop(.6,'#e3e7ea');g.addColorStop(1,'#5d646b');
 c.beginPath();c.arc(x,y,r,0,7);c.fillStyle=g;c.fill();c.lineWidth=1.5;c.strokeStyle='#2a2d30';c.stroke();
 g=c.createRadialGradient(x,y-r*.35,r*.1,x,y,r*.84);g.addColorStop(0,'#44484d');g.addColorStop(1,'#0b0c0e');
 c.beginPath();c.arc(x,y,r*.84,0,7);c.fillStyle=g;c.fill();
 c.beginPath();c.arc(x,y,r*.84,Math.PI*.12,Math.PI*.88);c.lineWidth=1.6;c.strokeStyle='#ffffff77';c.stroke();
 c.beginPath();c.arc(x,y,r*.6,Math.PI*1.1,Math.PI*1.8);c.lineWidth=1.2;c.strokeStyle='#ffffff22';c.stroke()}
// ---- vaso de ron en las rocas (se dibuja una vez con la mesa) ----
// Posavasos de madera, sombra y luz ámbar que pasa por el ron, vidrio grueso con fondo pesado, ron con degradado y
// superficie, hielos (distintos por encima y por debajo del ron), brillos de la lámpara, gotas de condensación y borde.
function rumGlass(bx,by){
 const Hh=94,yT=by-Hh,rT=41,eT=9,rB=35,eB=7.5,yL=by-50,yBase=by-15,R2=mulberry(77);
 const R=y=>rB+(rT-rB)*(by-y)/Hh,E=y=>eB+(eT-eB)*(by-y)/Hh;
 const body=()=>{c.beginPath();c.moveTo(bx-rT,yT);c.lineTo(bx-rB,by);c.ellipse(bx,by,rB,eB,0,Math.PI,0,true);c.lineTo(bx+rT,yT);c.ellipse(bx,yT,rT,eT,0,0,Math.PI,true);c.closePath()};
 const cav=(y0,y1,ins)=>{const r0=R(y0)-ins,r1=R(y1)-ins;c.beginPath();c.moveTo(bx-r0,y0);c.lineTo(bx-r1,y1);c.ellipse(bx,y1,r1,E(y1)*r1/R(y1),0,Math.PI,0,true);c.lineTo(bx+r0,y0);c.ellipse(bx,y0,r0,E(y0)*r0/R(y0),0,0,Math.PI,true);c.closePath()};
 // posavasos
 c.save();c.shadowColor='rgba(0,0,0,.75)';c.shadowBlur=8*SCS;c.shadowOffsetY=3*SCS;c.beginPath();c.ellipse(bx,by+3.5,56,15,0,0,7);c.fillStyle='#1d0f06';c.fill();c.restore();
 c.beginPath();c.ellipse(bx,by+1,56,15,0,0,7);c.fillStyle=woodAt(WOOD_RACK,.08,.35,bx,by);c.fill();
 let g=c.createRadialGradient(bx-14,by-4,4,bx,by+1,60);g.addColorStop(0,'rgba(255,220,170,.25)');g.addColorStop(1,'rgba(0,0,0,.4)');c.fillStyle=g;c.fill();
 c.beginPath();c.ellipse(bx,by+1,49,12.6,0,0,7);c.lineWidth=1;c.strokeStyle='rgba(0,0,0,.5)';c.stroke();
 c.beginPath();c.ellipse(bx,by+1.8,49,12.6,0,Math.PI*.1,Math.PI*.9);c.lineWidth=.7;c.strokeStyle='rgba(255,226,186,.3)';c.stroke();
 c.beginPath();c.ellipse(bx,by+1,56,15,0,Math.PI*1.08,Math.PI*1.92);c.lineWidth=1;c.strokeStyle='rgba(255,226,186,.5)';c.stroke();
 // sombra del vaso y luz ámbar que atraviesa el ron
 g=c.createRadialGradient(bx-4,by+2,4,bx-4,by+2,44);g.addColorStop(0,'rgba(0,0,0,.5)');g.addColorStop(1,'rgba(0,0,0,0)');c.fillStyle=g;c.beginPath();c.ellipse(bx-4,by+2,46,12.5,0,0,7);c.fill();
 c.save();c.globalCompositeOperation='screen';g=c.createRadialGradient(bx+18,by+8,1,bx+18,by+8,30);g.addColorStop(0,'rgba(255,175,70,.6)');g.addColorStop(.6,'rgba(255,140,40,.18)');g.addColorStop(1,'rgba(255,140,30,0)');
 c.fillStyle=g;c.beginPath();c.ellipse(bx+18,by+8,32,8.5,0,0,7);c.fill();c.restore();
 // interior del vaso (vidrio casi transparente)
 body();c.fillStyle='rgba(235,245,250,.07)';c.fill();
 c.beginPath();c.ellipse(bx,yT,rT-2.6,eT-1.1,0,0,7);c.fillStyle='rgba(20,10,4,.18)';c.fill();
 // ron
 c.save();cav(yL,yBase,2.6);c.clip();
 g=c.createLinearGradient(0,yL-8,0,yBase+7);g.addColorStop(0,'#f1b04c');g.addColorStop(.35,'#cf7821');g.addColorStop(1,'#622807');c.fillStyle=g;c.fillRect(bx-60,yL-20,120,80);
 g=c.createLinearGradient(bx-rT,0,bx+rT,0);g.addColorStop(0,'rgba(55,15,0,.62)');g.addColorStop(.17,'rgba(55,15,0,.1)');g.addColorStop(.55,'rgba(255,214,140,0)');g.addColorStop(.7,'rgba(255,218,150,.32)');g.addColorStop(.83,'rgba(255,214,140,0)');g.addColorStop(1,'rgba(55,15,0,.62)');
 c.fillStyle=g;c.fillRect(bx-60,yL-20,120,80);
 c.beginPath();c.ellipse(bx+4,yBase+1,R(yBase)-7,E(yBase)-1.5,0,0,7);g=c.createRadialGradient(bx+8,yBase,2,bx+4,yBase,R(yBase));g.addColorStop(0,'rgba(255,224,155,.55)');g.addColorStop(1,'rgba(255,200,120,0)');c.fillStyle=g;c.fill();
 c.restore();
 const rl=R(yL)-2.6,el=E(yL)*rl/R(yL);
 c.beginPath();c.ellipse(bx,yL,rl,el,0,0,7);g=c.createLinearGradient(0,yL-el,0,yL+el);g.addColorStop(0,'#b45f18');g.addColorStop(.55,'#e39d42');g.addColorStop(1,'#f6c977');c.fillStyle=g;c.fill();
 // hielos: por debajo del ron se ven teñidos de ámbar; por encima, claros con cantos brillantes
 const cubes=[[bx-13,yL-5,25,.38],[bx+13,yL-8,22,-.3],[bx+1,yL+3,19,1.05]];
 const shape=(cx,cy,sz,rot,dy)=>{c.save();c.translate(cx,cy+dy);c.scale(1,.56);c.rotate(rot);rr(-sz/2,-sz/2,sz,sz,sz*.3);c.restore()};
 const cube=(cx,cy,sz,rot,sub)=>{const dep=sz*.5;
  for(let k2=4;k2>=1;k2--){shape(cx,cy,sz,rot,dep*k2/4);c.fillStyle=sub?'rgba(255,212,145,.22)':'rgba(214,230,238,.45)';c.fill()}
  shape(cx,cy,sz,rot,dep);c.lineWidth=.8;c.strokeStyle=sub?'rgba(255,232,190,.5)':'rgba(255,255,255,.6)';c.stroke();
  if(sub)return;
  shape(cx,cy,sz,rot,0);g=c.createLinearGradient(cx-sz/2,cy-sz/3,cx+sz/2,cy+sz/3);g.addColorStop(0,'rgba(255,255,255,.95)');g.addColorStop(.5,'rgba(236,246,252,.6)');g.addColorStop(1,'rgba(205,225,235,.5)');
  c.fillStyle=g;c.fill();c.lineWidth=1.1;c.strokeStyle='rgba(255,255,255,.95)';c.stroke();
  c.beginPath();c.moveTo(cx-sz*.2,cy-sz*.05);c.quadraticCurveTo(cx,cy+sz*.04,cx+sz*.16,cy-sz*.1);c.lineWidth=.6;c.strokeStyle='rgba(255,255,255,.75)';c.stroke(); // grieta
  c.beginPath();c.ellipse(cx-sz*.18,cy-sz*.09,sz*.12,sz*.05,-.4,0,7);c.fillStyle='rgba(255,255,255,.9)';c.fill()};
 c.save();cav(yT+6,yBase,2.6);c.clip();
 c.save();c.beginPath();c.rect(bx-60,yL+el*.15,120,80);c.clip();for(const[x,y,z,r]of cubes)cube(x,y,z,r,true);c.restore();
 c.save();c.beginPath();c.rect(bx-60,yT,120,yL+el*.15-yT);c.clip();for(const[x,y,z,r]of cubes)cube(x,y,z,r,false);c.restore();
 c.restore();
 c.beginPath();c.ellipse(bx,yL,rl,el,0,Math.PI*.08,Math.PI*.92);c.lineWidth=1.2;c.strokeStyle='rgba(255,238,200,.85)';c.stroke(); // menisco
 // fondo grueso de vidrio
 c.beginPath();c.moveTo(bx-R(yBase),yBase);c.lineTo(bx-rB,by);c.ellipse(bx,by,rB,eB,0,Math.PI,0,true);c.lineTo(bx+R(yBase),yBase);c.ellipse(bx,yBase,R(yBase),E(yBase),0,0,Math.PI,false);c.closePath();
 g=c.createLinearGradient(0,yBase-3,0,by+eB);g.addColorStop(0,'rgba(255,186,105,.6)');g.addColorStop(.5,'rgba(255,220,170,.32)');g.addColorStop(1,'rgba(255,245,225,.45)');c.fillStyle=g;c.fill();
 c.beginPath();c.ellipse(bx,yBase,R(yBase)-2.6,E(yBase)-.8,0,Math.PI*.1,Math.PI*.9);c.lineWidth=.8;c.strokeStyle='rgba(255,240,210,.55)';c.stroke();
 c.beginPath();c.ellipse(bx,by,rB,eB,0,Math.PI*.04,Math.PI*.96);c.lineWidth=1.7;c.strokeStyle='rgba(255,255,255,.8)';c.stroke();
 // paredes de vidrio: grosor en los bordes y brillos de la lámpara (la lámpara está a la derecha, hacia el centro)
 c.save();body();c.clip();
 g=c.createLinearGradient(bx-rT,0,bx+rT,0);g.addColorStop(0,'rgba(255,255,255,.34)');g.addColorStop(.07,'rgba(255,255,255,.06)');g.addColorStop(.92,'rgba(255,255,255,.08)');g.addColorStop(1,'rgba(255,255,255,.4)');
 c.fillStyle=g;c.fillRect(bx-60,yT-12,120,Hh+24);
 for(const[x0,w,a]of[[19,6,.6],[12,2,.38],[-29,3,.3],[-22,1.2,.25]]){const gx=c.createLinearGradient(0,yT,0,by);gx.addColorStop(0,'rgba(255,255,255,0)');gx.addColorStop(.12,'rgba(255,255,255,'+a+')');gx.addColorStop(.75,'rgba(255,255,255,'+a*.55+')');gx.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=gx;c.beginPath();c.moveTo(bx+x0,yT+5);c.lineTo(bx+x0+w,yT+5);c.lineTo(bx+(x0+w)*rB/rT,by-4);c.lineTo(bx+x0*rB/rT,by-4);c.closePath();c.fill()}
 // gotas de condensación (más abajo, donde el vidrio está frío) y algunas que escurren
 g=c.createLinearGradient(0,yL-14,0,by);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.25,'rgba(255,250,240,.07)');g.addColorStop(1,'rgba(255,250,240,.1)');c.fillStyle=g;c.fillRect(bx-60,yL-14,120,by-yL+14); // vidrio empañado
 for(let i=0;i<150;i++){const y=yT+14+R2()*(Hh-18),dens=y>yL-12?1:.22,r=.45+R2()*R2()*1.9,x=bx+(R2()*2-1)*(R(y)-3);if(R2()>dens)continue;
  c.beginPath();c.arc(x+.25,y+.4,r,0,7);c.fillStyle='rgba(60,25,5,.12)';c.fill();
  c.beginPath();c.arc(x,y,r,0,7);c.fillStyle=y>yL?'rgba(255,238,205,.32)':'rgba(255,255,255,.2)';c.fill();
  c.beginPath();c.arc(x-r*.3,y-r*.3,r*.34,0,7);c.fillStyle='rgba(255,255,255,.8)';c.fill()}
 for(const fx of[-.58,.18,.66]){const x=bx+fx*R(yL),y0=yL+4+R2()*8,y1=by-5-R2()*6;
  c.beginPath();c.moveTo(x,y0);c.quadraticCurveTo(x+1.2,(y0+y1)/2,x+.4,y1);c.lineWidth=1.3;c.strokeStyle='rgba(255,245,225,.38)';c.stroke();
  c.beginPath();c.arc(x+.4,y1,2.3,0,7);c.fillStyle='rgba(255,240,215,.45)';c.fill();c.beginPath();c.arc(x-.3,y1-.7,.9,0,7);c.fillStyle='#fff';c.fill()}
 c.restore();
 // borde
 c.beginPath();c.ellipse(bx,yT,rT,eT,0,Math.PI,Math.PI*2);c.lineWidth=1.3;c.strokeStyle='rgba(255,255,255,.6)';c.stroke();
 c.beginPath();c.ellipse(bx,yT,rT-2.6,eT-1.1,0,0,7);c.lineWidth=.8;c.strokeStyle='rgba(255,255,255,.38)';c.stroke();
 c.beginPath();c.ellipse(bx,yT,rT,eT,0,0,Math.PI);c.lineWidth=2.1;c.strokeStyle='rgba(255,255,255,.92)';c.stroke();
 c.beginPath();c.arc(bx+rT*.5,yT+eT*.8,2.3,0,7);c.fillStyle='#fff';c.fill();
 c.beginPath();c.arc(bx+rT*.5,yT+eT*.8,5,0,7);c.fillStyle='rgba(255,255,255,.25)';c.fill();
 body();c.lineWidth=.8;c.strokeStyle='rgba(255,255,255,.5)';c.stroke();
 c.lineWidth=.5;c.strokeStyle='rgba(0,0,0,.25)';c.stroke()}
// polígono desplazado k hacia afuera (k<0 hacia adentro)
function offPoly(P,k){return P.map((p,i)=>{const p0=P[(i+P.length-1)%P.length],p1=P[(i+1)%P.length];
 const n=(a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy);return[dy/l,-dx/l]},n0=n(p0,p),n1=n(p,p1),mx=n0[0]+n1[0],my=n0[1]+n1[1],q=k/(1+n0[0]*n1[0]+n0[1]*n1[1]);return[p[0]+mx*q,p[1]+my*q]})}
const polyPath=P=>{c.beginPath();P.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.closePath()};
// rellena el anillo entre dos polígonos con una pieza de madera por lado: la veta sigue cada lado y las esquinas
// se unen a inglete (45°), como un marco de carpintería
function miterFill(outer,inner,pat,tones){
 for(let i=0;i<outer.length;i++){const j=(i+1)%outer.length,o0=outer[i],o1=outer[j],i0=inner[i],i1=inner[j];
  c.save();polyPath([o0,o1,i1,i0]);c.clip();
  c.fillStyle=woodAt(pat,Math.atan2(o1[1]-o0[1],o1[0]-o0[0]),.5,o0[0]+i*173,o0[1]+i*97);c.fillRect(-60,-60,VW+120,VH+120);
  if(tones){c.fillStyle=tones[i%tones.length];c.fillRect(-60,-60,VW+120,VH+120)}
  c.restore()}
 for(let i=0;i<outer.length;i++){const o0=outer[i],i0=inner[i];
  c.beginPath();c.moveTo(o0[0],o0[1]);c.lineTo(i0[0],i0[1]);c.lineWidth=1.8;c.strokeStyle='#000000a0';c.stroke();
  c.beginPath();c.moveTo(o0[0]+.9,o0[1]+.9);c.lineTo(i0[0]+.9,i0[1]+.9);c.lineWidth=.8;c.strokeStyle='#ffd9a040';c.stroke()}}
// tornillo de latón
function screw(x,y,r,rot){let g=c.createRadialGradient(x-r*.35,y-r*.4,r*.1,x,y,r);g.addColorStop(0,'#fff3c4');g.addColorStop(.45,'#c9a24a');g.addColorStop(1,'#5e4514');
 c.beginPath();c.arc(x,y+.8,r,0,7);c.fillStyle='#0008';c.fill();c.beginPath();c.arc(x,y,r,0,7);c.fillStyle=g;c.fill();c.lineWidth=.6;c.strokeStyle='#3a2a0a';c.stroke();
 c.save();c.translate(x,y);c.rotate(rot);c.fillStyle='#3a2a0acc';c.fillRect(-r*.8,-r*.16,r*1.6,r*.32);c.fillStyle='#fff6d055';c.fillRect(-r*.8,r*.16,r*1.6,r*.12);c.restore()}
// rayitas de uso sobre el barniz (dentro del recorte actual)
function scratches(seed,n,x0,y0,x1,y1){const R=mulberry(seed);c.lineCap='round';
 for(let i=0;i<n;i++){const x=x0+R()*(x1-x0),y=y0+R()*(y1-y0),a=R()*6.28,l=4+R()*26;
  c.beginPath();c.moveTo(x,y);c.quadraticCurveTo(x+Math.cos(a)*l*.5+R()*3,y+Math.sin(a)*l*.5+R()*3,x+Math.cos(a)*l,y+Math.sin(a)*l);
  c.lineWidth=.4+R()*.7;c.strokeStyle=R()<.7?'rgba(255,225,180,'+(.05+R()*.09)+')':'rgba(0,0,0,'+(.08+R()*.1)+')';c.stroke()}c.lineCap='butt'}
function drawStaticTable(){
 T2();
 const a=FA,b=FB,d=FD,e=FE;
 const bodyPath=keep=>{if(!keep)c.beginPath();c.moveTo(320,70);c.lineTo(1240,70);c.lineTo(1420,630);c.lineTo(140,630);c.closePath()};
 const surf=keep=>{if(!keep)c.beginPath();c.moveTo(a.x,a.y);c.lineTo(b.x,b.y);c.lineTo(d.x,d.y);c.lineTo(e.x,e.y);c.closePath()};
 // sombra en el piso + faldón frontal (da grosor a la mesa)
 let g=c.createRadialGradient(CX,700,40,CX,700,700);g.addColorStop(0,'#000000aa');g.addColorStop(1,'#00000000');
 c.save();c.translate(0,0);c.scale(1,.12);c.fillStyle=g;c.beginPath();c.arc(CX,700/.12,700,0,7);c.fill();c.restore();
 c.lineJoin='round';c.beginPath();c.moveTo(112,640);c.lineTo(1448,640);c.lineTo(1458,686);c.lineTo(102,686);c.closePath();
 c.lineWidth=6;c.strokeStyle='#140a04';c.stroke();c.fillStyle=woodAt(WOOD_BODY,0,.5,0,640);c.fill();
 g=c.createLinearGradient(0,640,0,686);g.addColorStop(0,'rgba(0,0,0,.18)');g.addColorStop(.3,'rgba(0,0,0,.45)');g.addColorStop(1,'rgba(0,0,0,.82)');c.fillStyle=g;c.fill();
 c.fillStyle='#ffffff18';c.fillRect(118,641,1324,2);
 // cuerpo de la mesa con sombra, bisel y madera
 c.save();c.shadowColor='#000c';c.shadowBlur=34*SCS;c.shadowOffsetY=12*SCS;bodyPath();c.lineWidth=60;c.strokeStyle='#24140a';c.fillStyle='#24140a';c.fill();c.stroke();c.restore();
 bodyPath();c.lineWidth=60;c.strokeStyle='#24140a';c.stroke();c.lineWidth=56;c.strokeStyle='#9a6a3c';c.stroke();
 const BODY=[[320,70],[1240,70],[1420,630],[140,630]],SURF=[[a.x,a.y],[b.x,b.y],[d.x,d.y],[e.x,e.y]];
 miterFill(offPoly(BODY,26),SURF,WOOD_BODY,['rgba(255,220,170,.05)','rgba(0,0,0,.05)','rgba(0,0,0,.10)','rgba(255,220,170,.02)']);
 g=c.createLinearGradient(200,70,1300,640);g.addColorStop(0,'rgba(255,225,180,.30)');g.addColorStop(.5,'rgba(255,225,180,.02)');g.addColorStop(1,'rgba(0,0,0,.42)');
 {const P=[[320,70],[1240,70],[1420,630],[140,630]],O=P.map((p,i)=>{const p0=P[(i+3)%4],p1=P[(i+1)%4];
   const n=(a,b)=>{const dx=b[0]-a[0],dy=b[1]-a[1],l=Math.hypot(dx,dy);return[dy/l,-dx/l]},n0=n(p0,p),n1=n(p,p1),mx=n0[0]+n1[0],my=n0[1]+n1[1],k=26/(1+n0[0]*n1[0]+n0[1]*n1[1]);return[p[0]+mx*k,p[1]+my*k]});
  c.beginPath();O.forEach((p,i)=>i?c.lineTo(p[0],p[1]):c.moveTo(p[0],p[1]));c.closePath();c.fillStyle=g;c.fill()}
 // barniz: brillo de la lámpara sobre el marco y rayitas de uso
 c.save();polyPath(offPoly(BODY,26));c.clip();
 g=c.createRadialGradient(CX,40,20,CX,120,620);g.addColorStop(0,'rgba(255,236,200,.26)');g.addColorStop(1,'rgba(255,236,200,0)');c.fillStyle=g;c.fillRect(0,0,VW,VH);
 for(const[x0,w,al]of[[420,90,.10],[930,140,.08]]){g=c.createLinearGradient(x0,0,x0+w,0);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.5,'rgba(255,250,235,'+al+')');g.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=g;c.beginPath();c.moveTo(x0,30);c.lineTo(x0+w,30);c.lineTo(x0+w-260,680);c.lineTo(x0-260,680);c.closePath();c.fill()}
 scratches(5,260,100,40,1460,660);c.restore();
 bodyPath();c.lineWidth=2.5;c.strokeStyle='#e3bb8a99';c.stroke();c.lineWidth=1;c.strokeStyle='#00000066';c.stroke();
 // portavasos cromados
 for(const[x,y,r]of[[215,522,40],[1205,585,38],[1215,122,27]])cupHolder(x,y,r);
 // vaso de ron con hielo sobre su posavasos
 rumGlass(505,100);
 // sombra de los atriles de los rivales sobre el marco
 for(const p of rackSeats()){const f=RKF[p];c.save();c.shadowColor='rgba(0,0,0,.85)';c.shadowBlur=9*SCS;c.shadowOffsetY=4*SCS;
  polyP([rp3(f,-RIN-RCAP-3,f.lean>0?-22:-36,0),rp3(f,RIN+RCAP+3,f.lean>0?-22:-36,0),rp3(f,RIN+RCAP+3,lipV(f)[1]+7,0),rp3(f,-RIN-RCAP-3,lipV(f)[1]+7,0)]);c.fillStyle='rgba(0,0,0,.45)';c.fill();c.restore()}
 rackBack();
 // superficie de juego
 surf();c.fillStyle='#e8e6dd';c.fill();c.save();surf();c.clip();
 g=c.createLinearGradient(0,a.y,0,e.y);g.addColorStop(0,'rgba(20,8,0,.30)');g.addColorStop(.5,'rgba(20,8,0,0)');g.addColorStop(1,'rgba(255,230,180,.08)');c.fillStyle=g;c.fillRect(0,0,VW,VH);
 flag();
 g=c.createLinearGradient(0,a.y,0,e.y);g.addColorStop(0,'rgba(10,4,0,.28)');g.addColorStop(.45,'rgba(10,4,0,0)');g.addColorStop(1,'rgba(255,240,210,.06)');c.fillStyle=g;c.fillRect(0,0,VW,VH);
 // barniz: reflejos de la lámpara
 g=c.createRadialGradient(CX,250,10,CX,300,560);g.addColorStop(0,'rgba(255,235,190,.17)');g.addColorStop(.6,'rgba(255,225,170,.06)');g.addColorStop(1,'rgba(255,225,170,0)');c.fillStyle=g;c.fillRect(0,0,VW,VH);
 for(const[x0,w,al]of[[360,150,.13],[640,60,.09],[1010,110,.10]]){g=c.createLinearGradient(x0,0,x0+w,0);g.addColorStop(0,'rgba(255,255,255,0)');g.addColorStop(.5,'rgba(255,255,255,'+al+')');g.addColorStop(1,'rgba(255,255,255,0)');
  c.fillStyle=g;c.beginPath();c.moveTo(x0,100);c.lineTo(x0+w,100);c.lineTo(x0+w-170,540);c.lineTo(x0-170,540);c.closePath();c.fill()}
 c.restore();
 inset(surf,26,7);
 // marco barnizado de la superficie
 surf();c.lineWidth=26;c.lineJoin='round';c.strokeStyle='#241309';c.stroke();
 miterFill(offPoly(SURF,11.5),offPoly(SURF,-11.5),WOOD_BODY,['rgba(0,0,0,.10)','rgba(0,0,0,.04)','rgba(255,220,170,.06)','rgba(0,0,0,.02)']);
 surf();c.lineWidth=23;
 g=c.createLinearGradient(0,a.y,0,e.y);g.addColorStop(0,'rgba(0,0,0,.35)');g.addColorStop(.5,'rgba(255,225,180,.10)');g.addColorStop(1,'rgba(255,225,180,.22)');c.strokeStyle=g;c.stroke();
 c.lineWidth=2;c.strokeStyle='#d6a56d';c.stroke();c.lineWidth=.8;c.strokeStyle='#0008';c.stroke();
 // viñeta general
 c.save();bodyPath();c.lineWidth=60;c.clip();bodyPath();c.clip();
 g=c.createRadialGradient(CX,330,200,CX,330,860);g.addColorStop(0,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.34)');c.fillStyle=g;c.fillRect(0,0,VW,VH);c.restore()}
// ---- tu atril: repisa de madera con respaldo bajo, topes en las puntas y labio delantero ----
// Parte fija (detrás de tus fichas): se dibuja una vez con la mesa. El labio va encima de las fichas (rackLip).
function rackBack(){
 const X0=CX-253,X1=CX+253;
 c.save();c.shadowColor='rgba(0,0,0,.85)';c.shadowBlur=14*SCS;c.shadowOffsetY=7*SCS;c.beginPath();c.roundRect(X0+6,548,X1-X0-12,116,10);c.fillStyle='rgba(0,0,0,.55)';c.fill();c.restore();
 // respaldo
 const bk=()=>{c.beginPath();c.roundRect(CX-232,558,464,72,[7,7,0,0])};
 bk();c.fillStyle=woodAt(WOOD_RACK,0,.5,CX-232,558);c.fill();
 let g=c.createLinearGradient(0,558,0,630);g.addColorStop(0,'rgba(255,222,178,.45)');g.addColorStop(.07,'rgba(255,222,178,.12)');g.addColorStop(.2,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(0,0,0,.6)');
 bk();c.fillStyle=g;c.fill();bk();c.lineWidth=1;c.strokeStyle='#000b';c.stroke();
 c.beginPath();c.moveTo(CX-226,559.5);c.lineTo(CX+226,559.5);c.lineWidth=1;c.strokeStyle='rgba(255,226,186,.5)';c.stroke();
 // ranura donde se paran las fichas
 c.fillStyle='#0d0501';c.fillRect(CX-232,616,464,16);
 // topes de las puntas: bloque con cara de arriba, cara de adelante y la cara de adentro en sombra
 for(const sd of[-1,1]){const x0=sd<0?X0:CX+231,w=22;
  c.beginPath();c.roundRect(x0,552,w,112,[7,7,5,5]);c.fillStyle=woodAt(WOOD_RACK,Math.PI/2,.5,x0,552);c.fill();
  g=c.createLinearGradient(x0,0,x0+w,0);g.addColorStop(0,sd<0?'rgba(255,222,178,.18)':'rgba(0,0,0,.42)');g.addColorStop(1,sd<0?'rgba(0,0,0,.42)':'rgba(255,222,178,.18)');c.fillStyle=g;c.fill();
  g=c.createLinearGradient(0,552,0,664);g.addColorStop(0,'rgba(255,226,186,.4)');g.addColorStop(.08,'rgba(255,226,186,.06)');g.addColorStop(1,'rgba(0,0,0,.5)');c.fillStyle=g;c.fill();
  c.lineWidth=1;c.strokeStyle='#000c';c.stroke();
  c.beginPath();c.moveTo(x0+4,553.5);c.lineTo(x0+w-4,553.5);c.lineWidth=1.2;c.strokeStyle='rgba(255,230,192,.6)';c.stroke()}}
// labio delantero de tu atril: tapa la base de las fichas paradas (las que levantas o arrastras pasan por encima)
function rackLip(){T2();const x0=CX-231,x1=CX+231;
 let g=c.createLinearGradient(0,606,0,627);g.addColorStop(0,'rgba(20,8,0,0)');g.addColorStop(1,'rgba(20,8,0,.32)');c.fillStyle=g;c.fillRect(x0,606,x1-x0,21);
 c.beginPath();c.roundRect(x0,626,x1-x0,38,[7,7,4,4]);c.fillStyle=woodAt(WOOD_RACK,0,.5,x0+90,626);c.fill();
 g=c.createLinearGradient(0,626,0,664);g.addColorStop(0,'rgba(255,226,186,.55)');g.addColorStop(.1,'rgba(255,226,186,.2)');g.addColorStop(.25,'rgba(255,226,186,.03)');g.addColorStop(.75,'rgba(0,0,0,.2)');g.addColorStop(1,'rgba(0,0,0,.58)');
 c.fillStyle=g;c.fill();c.lineWidth=1;c.strokeStyle='#0a0400';c.stroke();
 c.beginPath();c.moveTo(x0+6,628);c.lineTo(x1-6,628);c.lineWidth=1.2;c.strokeStyle='rgba(255,232,195,.62)';c.stroke();
 screw(x0+16,646,3.6,.7);screw(x1-16,646,3.6,2.1)}
// tu ficha en el atril, un poco recostada hacia adelante (la parte de arriba se aleja de ti, como en un atril de
// verdad): la cara se ve algo más angosta arriba y un poco más corta, el canto de arriba fino, y los puntos grabados
// siguen esa perspectiva
function handTile(x,y,sc,t,hl){
 const w=HW*sc,h=HL*sc,kT=.92,kH=.95,tc=5*sc,r=w*.13;
 const yB=y+h/2,yTp=yB-h*kH,wT=w*kT,Hh=yB-yTp;
 const M=(u,v)=>{const ww=wT+(w-wT)*v;return{x:x+u*ww,y:yTp+v*Hh}};      // u: -0.5..0.5 · v: 0 arriba .. 1 abajo
 const face=[M(-.5,0),M(.5,0),M(.5,1),M(-.5,1)];
 c.save();c.translate(4,2);roundPoly(face,r);c.fillStyle='rgba(0,0,0,.3)';c.fill();c.restore();                 // sombra
 const cap=[{x:x-wT/2+1,y:yTp+r},{x:x-wT/2+2.5,y:yTp-tc},{x:x+wT/2-2.5,y:yTp-tc},{x:x+wT/2-1,y:yTp+r}];             // canto de arriba
 roundPoly(cap,r*.8);let g=c.createLinearGradient(0,yTp-tc,0,yTp+2);g.addColorStop(0,TH.dark?'#4a4a4e':'#fffcf2');g.addColorStop(1,TH.dark?'#18181a':TH.edgeUp);c.fillStyle=g;c.fill();c.lineWidth=1;c.strokeStyle=TH.outline;c.stroke();
 roundPoly(face,r);g=c.createLinearGradient(0,yTp,0,yB);g.addColorStop(0,TH.face[0]);g.addColorStop(.5,TH.face[1]);g.addColorStop(1,TH.face[2]);c.fillStyle=g;c.fill();
 c.save();c.globalAlpha=.45*TH.tex;c.fillStyle=texAt(IVORY,0,.24*sc,x,yTp);c.fill();c.restore();                         // textura de marfil
 c.save();roundPoly(face,r);c.clip();                                                                              // bisel de los lados y canto de arriba con luz
 g=c.createLinearGradient(x-w/2,0,x+w/2,0);g.addColorStop(0,TH.dark?'rgba(255,255,255,.22)':'rgba(255,255,255,.8)');g.addColorStop(.1,'rgba(255,255,255,0)');g.addColorStop(.86,'rgba(0,0,0,0)');g.addColorStop(1,'rgba(70,52,20,.24)');
 c.fillStyle=g;c.fillRect(x-w/2-2,yTp-2,w+4,Hh+4);
 g=c.createLinearGradient(0,yTp,0,yTp+Hh*.12);g.addColorStop(0,TH.dark?'rgba(255,255,255,.16)':'rgba(255,255,255,.7)');g.addColorStop(1,'rgba(255,255,255,0)');c.fillStyle=g;c.fillRect(x-w/2-2,yTp-2,w+4,Hh*.12+2);
 c.restore();
 roundPoly(face,r);c.lineWidth=hl?3:1.1;c.strokeStyle=hl||TH.outline;c.stroke();
 const d0=M(-.35,.5),d1=M(.35,.5);c.lineCap='round';                                                                 // línea grabada
 c.beginPath();c.moveTo(d0.x,d0.y);c.lineTo(d1.x,d1.y);c.lineWidth=2.4*sc;c.strokeStyle=TH.lineHand;c.stroke();
 c.beginPath();c.moveTo(d0.x,d0.y+1.5*sc);c.lineTo(d1.x,d1.y+1.5*sc);c.lineWidth=1*sc;c.strokeStyle=TH.hi;c.stroke();c.lineCap='butt';
 const gg=w*.25,pr=w*.088;
 for(const[pv,vc]of[[t.a,.25],[t.b,.75]])for(const[px,py]of(PIP[pv]||[])){
  const v=vc+px*gg/Hh,u=-py*gg/w,P=M(u*w/(wT+(w-wT)*v),v),k2=(wT+(w-wT)*v)/w,rx=pr*k2,ry=pr*k2*kH;
  c.beginPath();c.ellipse(P.x+.5,P.y+1,rx,ry,0,0,7);c.fillStyle=TH.rim;c.fill();                                   // borde de luz del hueco
  const col=pipColor(pv),pg=c.createRadialGradient(P.x-rx*.35,P.y-ry*.4,rx*.1,P.x,P.y,rx);pg.addColorStop(0,TH.dark||PREFS.pips==='colores'?col:'#000');pg.addColorStop(1,PREFS.pips==='colores'?col:TH.pipIn);
  c.beginPath();c.ellipse(P.x,P.y,rx,ry,0,0,7);c.fillStyle=pg;c.fill()}
 const cc=M(0,.5),bg=c.createRadialGradient(cc.x-1,cc.y-1,.4,cc.x,cc.y,w*.05);bg.addColorStop(0,'#fff2bd');bg.addColorStop(1,'#94701e'); // pasador de latón
 c.beginPath();c.ellipse(cc.x,cc.y,w*.048,w*.046,0,0,7);c.fillStyle=bg;c.fill();c.lineWidth=.6;c.strokeStyle='#5a4210';c.stroke()}
function buildStatic(){
 const off=document.createElement('canvas');off.width=VW*SCS;off.height=VH*SCS;
 const sv=[c,KK,DX,DY,ROT,SCL,SHX,SHY];
 c=off.getContext('2d');KK=SCS;DX=DY=0;ROT=0;SCL=1;SHX=SHY=0;
 try{drawStaticTable()}finally{[c,KK,DX,DY,ROT,SCL,SHX,SHY]=sv}
 STATIC=off}
function scene(){
 backdrop();T2();
 if(!STATIC)buildStatic();
 c.drawImage(STATIC,0,0,VW,VH);
 // atriles de los rivales y del compañero, con sus fichas paradas
 for(const p of rackSeats()){const R=rackImg(p);T2();c.drawImage(R.off,R.x0,R.y0,R.w,R.h)}
 // barra ámbar del turno
 if(phase==='play'&&!pendingEnd&&!knock&&!corrido&&turn>=0){T2();const f=clamp(1-(now-turnT0)/turnDur);c.lineCap='round';c.lineWidth=12;c.strokeStyle='#f0b429';c.beginPath();
  if(turn===0){c.moveTo(CX-80*f,676);c.lineTo(CX+80*f,676)}
  else if(turn===2){c.moveTo(CX-80*f,107);c.lineTo(CX+80*f,107)}
  else{const E=turn===3?edgeL:edgeR,s=turn===3?24:-24,p0=E(.5-.2*f),p1=E(.5+.2*f);c.moveTo(p0.x+s*1.5,p0.y);c.lineTo(p1.x+s*1.5,p1.y)}
  c.stroke();c.lineCap='butt'}
 // placas con avatar y nombre (fuera de los rieles, para que no tapen las fichas)
 T2();
 if(NSEAT!==2){const e=edgeL(.5);plate(e.x-84,e.y+6,angL+Math.PI,3)}
 if(NSEAT!==2){const e=edgeR(.5);plate(e.x+84,e.y+6,angR,1)}
 plate(CX-318,552,0,0);if(NSEAT!==3)plate(CX,129,0,2)}
