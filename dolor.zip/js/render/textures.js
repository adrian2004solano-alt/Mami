// Dominó Dominicano · render/textures.js
// Texturas procedurales generadas una sola vez: marfil de las fichas y madera.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- textura de marfil: mate, con veta fina a lo largo de la ficha, manchas suaves de tono envejecido, grano,
// puntitos y rayitas de uso. Se superpone a todas las fichas para que no se vean lisas ni plásticas ----
let IVORY=null;
function makeIvory(){const N=256,o=document.createElement('canvas');o.width=o.height=N;const g=o.getContext('2d'),img=g.createImageData(N,N),D=img.data,nz=pnoise(91),nz2=pnoise(173),R=mulberry(5);
 for(let y=0;y<N;y++)for(let x=0;x<N;x++){const ux=x/N,uy=y/N;
  const v=(nz(ux*4,uy*4,4,4)-.5)*.55+(nz2(ux*9,uy*9,9,9)-.5)*.35+(nz2(ux*64,uy*5,64,5)-.5)*.6+(R()-.5)*.38,i=(y*N+x)*4;
  if(v>0){D[i]=255;D[i+1]=252;D[i+2]=238;D[i+3]=Math.min(255,v*95)}else{D[i]=118;D[i+1]=92;D[i+2]=52;D[i+3]=Math.min(255,-v*105)}}
 g.putImageData(img,0,0);
 for(let k=0;k<80;k++){g.fillStyle='rgba(95,72,40,'+(.18+R()*.3)+')';g.beginPath();g.arc(R()*N,R()*N,.4+R()*1,0,7);g.fill()}
 g.lineCap='round';for(let k=0;k<30;k++){const x=R()*N,y=R()*N,a=R()*6.28,l=6+R()*34;g.beginPath();g.moveTo(x,y);g.quadraticCurveTo(x+Math.cos(a)*l*.5+R()*4-2,y+Math.sin(a)*l*.5+R()*4-2,x+Math.cos(a)*l,y+Math.sin(a)*l);
  g.lineWidth=.5+R()*.7;g.strokeStyle=R()<.55?'rgba(255,255,255,.4)':'rgba(105,82,48,.22)';g.stroke()}
 return c.createPattern(o,'repeat')}
// ---- texturas de madera (se generan una sola vez al cargar) ----
function mulberry(a){return function(){a|=0;a=a+0x6D2B79F5|0;let t=Math.imul(a^a>>>15,1|a);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296}}
// ---- madera realista generada pixel a pixel (una sola vez al cargar) ----
// Ruido periódico: la textura se repite sin costuras. Cada tabla tiene su tono, anillos de crecimiento con "catedrales",
// fibras finas, poros abiertos, nudos con la veta que los rodea y juntas de testa entre tablas.
function pnoise(seed){const R=mulberry(seed),P=new Uint8Array(512),V=new Float32Array(256);
 for(let i=0;i<256;i++){P[i]=i;V[i]=R()}for(let i=255;i>0;i--){const j=Math.floor(R()*(i+1)),t=P[i];P[i]=P[j];P[j]=t}for(let i=0;i<256;i++)P[i+256]=P[i];
 return(x,y,px,py)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,x0=((xi%px)+px)%px,y0=((yi%py)+py)%py,x1=(x0+1)%px,y1=(y0+1)%py,
  u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=V[P[P[x0]+y0]],b=V[P[P[x1]+y0]],c2=V[P[P[x0]+y1]],d=V[P[P[x1]+y1]];
  return a+(b-a)*u+(c2-a)*v+(a-b-c2+d)*u*v}}
function woodTex(o){
 const N=o.w||1024,M=o.h||1024,cv2=document.createElement('canvas');cv2.width=N;cv2.height=M;const g=cv2.getContext('2d'),img=g.createImageData(N,M),D=img.data;
 const R=mulberry(o.seed),nz=pnoise(o.seed*7+1),nz2=pnoise(o.seed*13+5),planks=o.planks||4,ph=M/planks;
 const L0=o.light,D0=o.dark,TAU=Math.PI*2;
 // por tabla: tono, desfase de anillos, catedral y juntas de testa (cada tramo entre juntas tiene veta propia)
 const PL=[];for(let p=0;p<planks;p++){const segs=[],nj=o.joints===false?0:(R()<.75?1:2);let xs=[];for(let j=0;j<nj;j++)xs.push(Math.floor(R()*N));xs.sort((a,b)=>a-b);
  const cuts=xs.length?xs:[0];for(let s=0;s<cuts.length;s++)segs.push({x0:cuts[s],off:R()*9,cx:R(),cw:.12+R()*.2,cath:R()<.6?1.2+R()*2.2:0,tint:(R()*2-1)*.09,sc:.8+R()*.5});
  PL.push({xs,segs})}
 const KN=[];for(let i=0;i<(o.knots||0);i++)KN.push({x:R()*N,y:(Math.floor(R()*planks)+.3+R()*.4)*ph,r:4+R()*7,a:2+R()*3});
 const rings=o.rings||14;
 for(let y=0;y<M;y++){const p=Math.floor(y/ph),v=(y-p*ph)/ph,pl=PL[p];
  for(let x=0;x<N;x++){
   // tramo (entre juntas) donde cae x
   let sg=pl.segs[pl.segs.length-1];if(pl.xs.length){sg=pl.segs[pl.segs.length-1];for(let s=0;s<pl.xs.length;s++){if(x>=pl.xs[s])sg=pl.segs[s]}if(x<pl.xs[0])sg=pl.segs[pl.segs.length-1]}
   const ux=x/N,uy=y/M;
   // deformación suave de la veta + catedral
   const w1=nz(ux*3,uy*planks*2,3,planks*2),w2=nz(ux*12,uy*planks*8,12,planks*8);
   let d=v*rings*sg.sc+sg.off+(w1-.5)*1.1+(w2-.5)*.22+(sg.cath?(()=>{let dx=Math.abs(ux-sg.cx);if(dx>.5)dx=1-dx;const q=dx/sg.cw;return sg.cath/(1+q*q*q*q)*(.25+.75*v)})():0);
   // nudos: la veta se curva alrededor
   let core=0;for(const k of KN){let dx=Math.abs(x-k.x);if(dx>N/2)dx=N-dx;const dy=(y-k.y)*2.2,q=(dx*dx+dy*dy)/(k.r*k.r);if(q<60){d+=k.a*Math.exp(-q*.12);if(q<1)core=Math.max(core,1-q)}}
   const r=d-Math.floor(d);
   // anillo: madera temprana clara, tardía oscura con borde nítido
   const sr=.5-.5*Math.cos(TAU*r);let t=Math.pow(sr,2.2)*.42+Math.pow(r,8)*.22;
   // fibras largas y finas
   const f=nz2(ux*6,uy*256,6,256)-.5,f2=nz(ux*24,uy*512,24,256)-.5;t+=f*.42+f2*.2;
   // poros abiertos (rayitas oscuras a lo largo de la veta)
   const po=nz2(ux*96,uy*384,96,256);if(po>.8)t+=(po-.8)*1.8*(.4+sr);
   t+=sg.tint+.22;if(core>0)t+=core*.5+Math.sin(core*26)*.1;
   t=t<0?0:t>1?1:t;
   let cr=L0[0]+(D0[0]-L0[0])*t,cgv=L0[1]+(D0[1]-L0[1])*t,cb=L0[2]+(D0[2]-L0[2])*t;
   // juntas: entre tablas (largo) y de testa (corte)
   const ey=y-p*ph;let sh=1;
   if(ey<1.6)sh=.38;else if(ey<3)sh=1.22;else if(ey>ph-1.5)sh=.7;
   for(const jx of pl.xs){const dj=x-jx;if(dj>=-1&&dj<1)sh=.35;else if(dj>=1&&dj<2.5)sh=Math.min(sh,1.18)}
   const i=(y*N+x)*4;D[i]=cr*sh;D[i+1]=cgv*sh;D[i+2]=cb*sh;D[i+3]=255}}
 g.putImageData(img,0,0);
 const pat=c.createPattern(cv2,'repeat');pat.base=cv2;return pat}
// patrón girado/escalado (la textura está al doble de resolución que la mesa)
function woodAt(pat,ang,s=.5,ox=0,oy=0){if(pat.setTransform)pat.setTransform(new DOMMatrix().translate(ox,oy).rotate(ang*180/Math.PI).scale(s));return pat}
// madera de la mesa y de los atriles según la personalización (WOODS en theme.js); se guarda por tipo de madera
let WOOD_BODY=null,WOOD_RACK=null;const WOOD_CACHE={};
function buildWood(){const w=WOODS[PREFS.wood]||WOODS.nogal,key=PREFS.wood;
 if(!WOOD_CACHE[key])WOOD_CACHE[key]=[woodTex({seed:7,light:w.body[0],dark:w.body[1],planks:4,rings:14,knots:3}),woodTex({seed:31,w:1024,h:256,light:w.rack[0],dark:w.rack[1],planks:2,rings:16,knots:1})];
 [WOOD_BODY,WOOD_RACK]=WOOD_CACHE[key]}
buildWood();IVORY=makeIvory();
// el fondo (backdrop) ahora está en render/ambient.js
