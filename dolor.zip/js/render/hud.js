// Dominó Dominicano · render/hud.js
// Elementos de interfaz dibujados en el lienzo (letreros, placas de nombre).
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- dibujo ----
function pill(x,y,txt,font,bg,fg,h=26,al=1){c.globalAlpha=al;c.font=font;const w=c.measureText(txt).width+22;rr(x-w/2,y-h/2,w,h,h/2);c.fillStyle=bg;c.fill();c.fillStyle=fg;c.textAlign='center';c.textBaseline='middle';c.fillText(txt,x,y+1);c.globalAlpha=1}
function quad(pts,fill,stroke){c.beginPath();pts.forEach((p,i)=>i?c.lineTo(p.x,p.y):c.moveTo(p.x,p.y));c.closePath();c.fillStyle=fill;c.fill();if(stroke){c.lineWidth=3;c.strokeStyle=stroke;c.stroke()}}
// placa del jugador: avatar, nombre, BOT si es la computadora; se ilumina cuando le toca
const AVIMG={};
function avatarImg(code){if(!code)return null;if(!AVIMG[code]){const im=new Image();im.src=DomProfile.dataUri(code,96);AVIMG[code]=im}return AVIMG[code]}
function plate(x,y,a,seat){const P=SEATS[seat]||{name:NAMES[seat]},name=seat===0?(P.name||'Tú'):P.name,on=phase==='play'&&turn===seat&&!pendingEnd;
 c.font='bold 16px system-ui';const tw=Math.min(150,c.measureText(name).width),bot=P.bot||P.left,len=tw+50+(bot?36:0);
 TS(x,y,a,.9);
 if(on){c.save();c.shadowColor='#f0b429';c.shadowBlur=18;rr(-len/2,-18,len,36,18);c.fillStyle='#f0b429';c.fill();c.restore()}
 rr(-len/2,-18,len,36,18);c.fillStyle='#f4f2e9';c.fill();c.lineWidth=on?3:1.5;c.strokeStyle=on?'#f0b429':'#c9c4b0';c.stroke();
 const im=avatarImg(P.avatar),ax=-len/2+18;
 c.save();c.beginPath();c.arc(ax,0,15,0,7);c.clip();if(im&&im.complete)c.drawImage(im,ax-15,-15,30,30);else{c.fillStyle='#244f9e';c.fill()}c.restore();
 c.fillStyle=P.connected===false&&!P.bot?'#9a948a':'#1c1c1c';c.textAlign='left';c.textBaseline='middle';c.fillText(name,ax+22,1,150);
 if(bot){const bx=ax+22+tw+6;rr(bx,-9,30,18,5);c.fillStyle=P.left?'#7a1f1f':'#3b3127';c.fill();c.fillStyle='#fff';c.font='bold 10px system-ui';c.textAlign='center';c.fillText(P.left?'SALIÓ':'BOT',bx+15,1)}
 if(P.connected===false&&!P.bot&&!P.left){c.beginPath();c.arc(len/2-8,-11,4,0,7);c.fillStyle='#d33';c.fill()}}
// globos del chat de la mesa sobre cada asiento
let chatLog=[];
function tableChat(m){const s=seatOf(m.seat);chatLog.push({s,name:m.name,text:m.text,t0:now});if(chatLog.length>40)chatLog.shift();if(typeof onTableChat==='function')onTableChat(m,s)}
function drawChatBubbles(){T2();const pos=[[CX-170,470],[1140,250],[CX+200,170],[420,250]];
 for(const b of chatLog){const ag=now-b.t0;if(ag>4500)continue;const[x,y]=pos[b.s];const al=clamp((4500-ag)/400);
  c.globalAlpha=al;c.font='bold 15px system-ui';const t=b.text.length>48?b.text.slice(0,46)+'…':b.text,w=Math.min(380,c.measureText(t).width+26);
  rr(x-w/2,y-18,w,36,14);c.fillStyle='#fffdf5';c.fill();c.lineWidth=1.5;c.strokeStyle='#c9b98f';c.stroke();
  c.fillStyle='#2a1d12';c.textAlign='center';c.textBaseline='middle';c.fillText(t,x,y+1,360);c.globalAlpha=1}}
