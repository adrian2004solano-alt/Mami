// Dominó Dominicano · conexión con el servidor (cuenta, API y tiempo real)
// Si el sitio está en otro dominio que el servidor, pon su dirección en js/app/server-url.js.
const NET=(()=>{
 const base=(window.DOMINO_SERVER||'').replace(/\/+$/,'');
 const L={};let ws=null,tries=0,token=null,alive=false,stopped=false;
 try{token=localStorage.getItem('domino.token')}catch(e){}
 const on=(t,fn)=>{(L[t]=L[t]||[]).push(fn)},emit=(t,m)=>{(L[t]||[]).forEach(f=>{try{f(m)}catch(e){console.error(e)}});(L['*']||[]).forEach(f=>f(m))};
 async function api(path,body){
  const ctl=new AbortController(),tm=setTimeout(()=>ctl.abort(),10000);
  let res;try{res=await fetch(base+path,{method:body?'POST':'GET',headers:Object.assign({'Content-Type':'application/json'},token?{Authorization:'Bearer '+token}:{}),body:body?JSON.stringify(body):undefined,signal:ctl.signal})}
  catch(e){const err=new Error('Sin conexión con el servidor');err.status=0;throw err}finally{clearTimeout(tm)}
  // si el hosting no tiene el servidor del juego (solo archivos), responde HTML: eso es "sin servidor"
  if(!/json/i.test(res.headers.get('content-type')||'')){const err=new Error('Sin servidor del juego');err.status=0;throw err}
  let data={};try{data=await res.json()}catch(e){}
  if(!res.ok){const err=new Error(data.error||'Error '+res.status);err.status=res.status;throw err}
  return data}
 function setToken(t){token=t;try{localStorage.setItem('domino.token',t)}catch(e){}}
 // cuenta: si no hay, se crea una de invitado
 async function ensureAccount(){
  if(token){try{const r=await api('/api/me');if(r&&r.me)return r.me}catch(e){if(e.status!==401)throw e}}
  const g=await api('/api/guest',{});if(!g||!g.token||!g.me)throw new Error('Sin servidor del juego');setToken(g.token);return g.me}
 function connect(){
  if(stopped)return;
  const url=(base||location.origin).replace(/^http/,'ws')+'/ws';
  ws=new WebSocket(url);
  ws.onopen=()=>{tries=0;ws.send(JSON.stringify({t:'hello',token}))};
  ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(_){return}if(m.t==='welcome'){alive=true;emit('status',true)}emit(m.t,m)};
  ws.onclose=ev=>{const was=alive;alive=false;if(was)emit('status',false);if(ev.code===4003||ev.code===4001&&!token)return;
   setTimeout(connect,Math.min(15000,800*Math.pow(1.7,tries++)))};
 }
 const send=m=>{if(ws&&ws.readyState===1)ws.send(JSON.stringify(m));else emit('status',false)};
 return{api,on,send,connect,ensureAccount,setToken,get online(){return alive},get token(){return token},logout(){try{localStorage.removeItem('domino.token')}catch(e){}token=null;stopped=true;if(ws)ws.close()}};
})();
