// Dominó Dominicano · cargador
// Primero se pinta la pantalla de carga y después se cargan los scripts del juego, en este orden exacto
// (comparten el ámbito global; cada uno usa lo definido en los anteriores).
(function () {
  var FILES = [
    'shared/engine.js', 'shared/room.js', 'shared/profile.js',
    'js/app/version.js', 'js/app/server-url.js',
    'js/core/config.js', 'js/core/screen.js', 'js/core/projection.js', 'js/core/audio.js',
    'js/render/theme.js', 'js/render/tile.js', 'js/game/state.js', 'js/render/racks.js', 'js/game/layout.js',
    'js/game/flow.js', 'js/game/driver.js', 'js/game/input.js', 'js/game/update.js', 'js/render/hud.js',
    'js/render/textures.js', 'js/render/ambient.js', 'js/render/table.js', 'js/render/scene.js',
    'js/lobby/net.js', 'js/lobby/lobby.js', 'js/lobby/sala.js', 'js/lobby/home.js', 'js/app/main.js'
  ];
  function fail(msg) {
    var el = document.getElementById('splash-msg');
    if (el) el.textContent = 'No se pudo cargar el juego. Recarga la página. (' + msg + ')';
  }
  function load(i) {
    if (i >= FILES.length) return;
    var s = document.createElement('script');
    s.src = FILES[i]; // rutas relativas: funciona en cualquier hosting y en una subcarpeta
    s.onload = function () { load(i + 1); };
    s.onerror = function () { fail(FILES[i]); };
    document.body.appendChild(s);
  }
  // deja que el navegador pinte la pantalla de carga antes de generar las texturas (tarda un poco en teléfonos)
  requestAnimationFrame(function () { setTimeout(function () { load(0); }, 30); });
})();
