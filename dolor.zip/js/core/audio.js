// Dominó Dominicano · core/audio.js
// Sonidos generados con Web Audio (sin archivos): golpes, fichas, monedas.
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
// ---- sonido ----
let AC=null,muted=false;
function snd(kind,vol=1){if(muted)return;try{AC=AC||new(window.AudioContext||window.webkitAudioContext)();const t=AC.currentTime;
 const fr={knock:260,slam:150,pick:1100,place:1500,deal:1500}[kind]||1500,len=kind==='slam'?.26:kind==='knock'?.12:.06;
 const b=AC.createBuffer(1,AC.sampleRate*len,AC.sampleRate),d=b.getChannelData(0);
 for(let j=0;j<d.length;j++)d[j]=(Math.random()*2-1)*Math.pow(1-j/d.length,3);
 const s=AC.createBufferSource(),f=AC.createBiquadFilter(),g=AC.createGain();s.buffer=b;f.type='bandpass';f.frequency.value=fr;g.gain.value=(kind==='slam'?2.6:kind==='knock'?1.4:.6)*vol;
 s.connect(f);f.connect(g);g.connect(AC.destination);s.start(t)}catch(e){}}
