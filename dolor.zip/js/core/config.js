// Dominó Dominicano · core/config.js
// Lienzo, contexto 2D y constantes generales del juego (tamaño de la mesa, fichas, mano, meta de puntos).
// Nota: todos los archivos de js/core, js/game y js/render comparten el mismo ámbito global y se cargan en el orden
// definido en js/app/loader.js (no cambies ese orden sin probar).
const cv=document.getElementById('c');let c=cv.getContext('2d');
if(!CanvasRenderingContext2D.prototype.roundRect)CanvasRenderingContext2D.prototype.roundRect=function(x,y,w,h,r){r=Math.min(r,w/2,h/2);this.moveTo(x+r,y);this.arcTo(x+w,y,x+w,y+h,r);this.arcTo(x+w,y+h,x,y+h,r);this.arcTo(x,y+h,x,y,r);this.arcTo(x,y,x+w,y,r);this.closePath()};
const VW=1560,VH=720,CX=780,BW=960,BH=480,Q=.2195,CC=2111,YH=505-CC;
const L=72,W=36,HW=60,HL=120,HY=572,STEP=63,TARGET=100,RO=60;
const NAMES=['Tú','Rival 1','Compañero','Rival 2'];
let KK=1,DX=0,DY=0,k=1,ox=0,oy=0,dpr=1,now=0,ROT=0,SCL=1;

// dinero: el servidor guarda centavos de dólar (1000 = $10.00)
function money(c){c=Math.round(+c||0);const neg=c<0;c=Math.abs(c);const d=c/100;return(neg?'−':'')+'$'+d.toLocaleString('en-US',{minimumFractionDigits:c%100?2:0,maximumFractionDigits:2})}
